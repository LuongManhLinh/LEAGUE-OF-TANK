#pragma once

#include "VectorAndCircle.h"
#include "LTexture.h"
#include "LTimer.h"
#include "Bullet.h"
#include "checkCollision.h"
#include "Turret.h"
#include "vector"
#include "Ore.h"

class Tank
{
public:

    const static int TANK_WIDTH = 50;
    const static int TANK_HEIGHT = 50;
    const static int BULLET_VEL = 800;

    int MAX_CAPACITY = 200;

    const static Uint32 ALERT_TIME = 3000;


    Tank();
    void setRenderer (SDL_Renderer *_renderer);
    void setFont (TTF_Font *gFont);
    void setTextures(LTexture up[], LTexture& bot, LTexture broken[]);
    void setBulletTexture(LTexture texture[]);
    void setOresTexture(LTexture &iron, LTexture &titan, LTexture &sulfur);
    void setFumeTexture(LTexture fume[]);

    void handleEvent(SDL_Event& e);
    void move(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, vector<ArrayIndex>& river, vector <Tank> &enemies, float& time, Ore& iron, Ore& titan, Ore& sulfur);
    void doShoot(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, vector <Tank> &enemies, float& time, Ore& iron, Ore& titan, Ore& sulfur);

    void checkStatus(Tank *enemy = NULL);

    void render();
    void renderFume(Uint32 deadTime);
    //void renderExplosion();

    SDL_Rect getRect();
    void chooseToPlay(bool yesOrNo);

    void decreaseHP(float amount);
    void decreaseTurretHP(float amount, Uint8 index);


    void setRespawnPoint(SDL_Point& point);
    void setPosition(int _x, int _y);

    void chooseTurret(vector <Turret>& imTurret);

    vector <SDL_Rect> getTurretRect();
    float getHP();
    float getTurretHP(Uint8 index);
    bool ifIsReloading();

    int getNumberAvailableBullet();
    int getNumberBulletInStorage();


    void turretAttack(Tank& enemyTank, float time);

    void setStorageRect(SDL_Rect rect);

    int getNumberIron();
    int getNumberTitan();
    int getNumberSulfur();

    int getNumberStoredIron();
    int getNumberStoredTitan();
    int getNumberStoredSulfur();
    float getArmor();
    float getMaxArmor();

    bool upgradeTableOpened();
    void receiveUpgrades(vector <Tank>& enemies);

    Uint8 getLevel(Uint8 type);

    bool isEnoughMaterial (Uint8 index);

    int getPosX();
    int getPosY();

    bool isAllowShoot();
    void setDeadTime(Uint32 time);

    int getKills();
    int getDeaths();

    //AI Parts
    void AI_setOrbit(vector<SDL_Point> &setPoint);
    void AI_setAlertRange (vector <SDL_Rect>& range);
    void AI_move(float &time, Tank& enemy);
    void AI_shoot(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, Tank& otherTank, float& time, Ore& iron, Ore& titan, Ore& sulfur);
    void AI_checkEnemy(Tank& enemy);
    void beAlerted();
    bool containingOres();
    void stealed();

    void AI_increasePower(Uint32 GAME_TIME);
    //
    void setHPBarTexture (LTexture &_HPBar, LTexture &_HPFrame, LTexture &_ArmorBar);

    void setTimeLineTexture (LTexture &line);

    void pauseAllTimer();
    void unPauseAllTimer();

    //sounds
    void setSounds(Mix_Chunk *shootSound, Mix_Chunk *takeDamageSound, Mix_Chunk *armorSound = NULL, Mix_Chunk *takeOreSound = NULL,
                   Mix_Chunk *buttonSound = NULL, Mix_Chunk *upgradeSound = NULL, Mix_Chunk *runOutOfBulletSound = NULL, Mix_Chunk *reloadingSound = NULL);

    void setTurretSound (Mix_Chunk *electricSound);
    //
    void reset();
    void AI_reset();
private:
    float x, y;
    float velX, velY;
    int bottomAngle, upAngle;

    bool checkFirstKey;

    SDL_Point spinPoint;
    int mX, mY;
    SDL_Point shootPoint;

    SDL_Renderer *renderer;
    TTF_Font *tFont;

    LTexture upTexture[4], downTexture;
    LTexture upBrokenTexture[4];
    LTexture fumeTexture[5];
    LTexture bulletTexture[4];

    Vector bulletDirect;
    vector <Bullet> tankBullets;
    int bulletIndex;
    Uint16 availableBullet, bulletInStorage;

    LTimer shootTimer;
    LTimer reloadTimer;

    bool allowShoot;
    bool allowReloading;
    bool allowMove;
    bool isReloading;

    SDL_Rect tankRect;
    SDL_Rect storageRect;

    bool isPlaying;
    float HP;
    float ARMOR;
    float MAX_TANK_HP;

    LTimer deadTimer;
    bool isDead;
    bool diedByWater;

    SDL_Point respawnPoint;

    vector <Turret> turret;

    int capacity;
    int bringingIron, bringingTitan, bringingSulfur;
    int numberOreGot;

    int storedIron, storedTitan, storedSulfur;

    //Indicators that can be upgraded
    float MAX_ARMOR;
    Uint16 NUMBER_BULLET;
    Uint16 MAX_BULLET_IN_STORAGE;
    int TANK_VEL;
    Uint32 TIME_DELAY_RELOAD;
    Uint32 TIME_DELAY_SHOOT;
    float DAMAGE;

    Uint8 upgradeIndex;
    bool upgradeRequest[8];
    bool openUpgradeTable;
    Uint8 lvArmor, lvNumberBullet, lvMaxBulletInStorage, lvTankVel, lvTImeDelayReload, lvTimeDelayShoot, lvDamage;
    bool enoughMaterial[3];

    Uint32 DEAD_TIME;

    LTexture damageTexture[10];
    Uint8 damageIndex;
    float damageRenderPosX[10], damageRenderPosY[10];
    float sectionRendered[10];

    int kills, deaths;

    //For the AI
    vector <SDL_Rect> alertRange;
    vector <SDL_Point> orbitPoints;
    Uint8 numberPoint;
    Vector moveDirection;
    int passedIndex, nextIndex;

    float distanceTraveled;
    float totalDistance;
    bool isTurningBack;

    bool enemyDetected;
    LTimer alertTimer;
    bool isStealed;
    bool changeAllowMoveWhileShooting;
    bool doIncreasePower;
    //
    LTexture HPFrame, HPBar, ArmorBar;
    SDL_Rect HPRect, ArmorRect;

    LTexture timeLine;
    SDL_Rect timeRect;
    bool renderDeadTime;

    Mix_Chunk *shootSound, *takeDamageSound, *armorSound, *takeOreSound;
    Mix_Chunk *runOutOfBulletSound, *reloadingSound;
    Mix_Chunk *buttonSound, *upgradeSound;

    Mix_Chunk *electricSound;
};

//const Uint8 MAX_LEVEL = 3;
extern float LV_ARMOR[4];                 //1
extern Uint16 LV_NUMBER_BULLET[4];        //2
extern Uint16 LV_MAX_BULLET_IN_STORAGE[4];//3
extern int LV_TANK_VEL[4];                //4
extern Uint32 LV_TIME_DELAY_RELOAD[4];    //5
extern Uint32 LV_TIME_DELAY_SHOOT[4];     //6
extern float LV_DAMAGE[4];                //7

struct Material
{
    Uint8 iron, titan, sulfur;
    Material();
    Material(Uint8 iron, Uint8 titan, Uint8 sulfur);
};

extern Material UPGRADE_MATERIAL[8][4];
                            //[type][level]
