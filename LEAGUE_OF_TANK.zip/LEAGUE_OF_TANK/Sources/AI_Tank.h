#pragma once

#include "Tank.h"

class AI_Tank
{
public:
    const static int TANK_WIDTH = 50;
    const static int TANK_HEIGHT = 50;
    const static int BULLET_VEL = 800;

    const float MAX_TANK_HP = 10;

    const Uint8 NUMBER_BULLET = 10;
    const Uint32 DEAD_TIME = 10000;
    const Uint32 TIME_DELAY_SHOOT = 250;

    AI_Tank();

    void setRenderer(SDL_Renderer *_renderer);
    void setTextures(LTexture &up, LTexture &bot, LTexture &broken);
    void setFumeTexture(LTexture fume[]);
    void setBulletTexture(LTexture &texture);

    void setOrbit(vector<SDL_Point> &setPoint);
    void setAlertRange (float radius);
    void move(float &time);
    void shoot(MapByBlock block[][NUMBER_BLOCK_HEIGHT], vector<ArrayIndex>& walls, Tank& otherTank, float& time, Ore& iron, Ore& titan, Ore& sulfur);

    void checkEnemy(Tank& enemy);

    void checkStatus();

    void render();

    void setPos(int _x, int _y);

private:
    Circle alertRange;
    float x, y;
    float velX, velY;

    vector <SDL_Point> orbitPoints;
    Uint8 numberPoint;
    Vector moveDirection;
    int passedIndex, nextIndex;

    float bottomAngle, upAngle;

    SDL_Point spinPoint;
    int mX, mY;
    SDL_Point shootPoint;

    SDL_Renderer *renderer;

    LTexture upTexture, downTexture;
    LTexture upBrokenTexture;
    LTexture fumeTexture[5];
    LTexture bulletTexture;

    Vector bulletDirect;
    vector <Bullet> tankBullets;
    int bulletIndex;
    Uint16 availableBullet, bulletInStorage;

    LTimer shootTimer;
    LTimer reloadTimer;
    LTimer deadTimer;

    bool allowShoot;
    bool allowMove;
    bool isTurningBack;

    SDL_Rect tankRect;
    SDL_Rect storageRect;

    float HP;
    float ARMOR;
    int TANK_VEL;
    float DAMAGE;

    bool isDead;

    SDL_Point respawnPoint;
};
