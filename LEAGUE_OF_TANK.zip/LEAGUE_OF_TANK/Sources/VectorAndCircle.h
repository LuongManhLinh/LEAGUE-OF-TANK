#pragma once

#include "iostream"
#include "cmath"
#include "SDL2/SDL.h"

struct Vector
{
    float x;
    float y;
    Vector();
    Vector(float _x, float _y);
    float getLength();
    float getAngleToOx();
};

enum gocPhanTu
{
    I, II, III, IV
};

gocPhanTu kiemTraGocVector(Vector vct);


struct Circle
{
    int x, y;
    int r;

};

struct MapByBlock
{
    SDL_Rect block;
    int index;

};

struct ArrayIndex
{
    int x;
    int y;

    ArrayIndex(int _x, int _y);

};
