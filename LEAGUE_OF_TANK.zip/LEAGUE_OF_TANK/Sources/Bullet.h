#pragma once


#include "SDL2/SDL.h"
#include "LTexture.h"
#include "VectorAndCircle.h"

struct Bullet
{
    Vector direct;
    float x, y;
    float velX, velY;
    LTexture texture;
    SDL_Rect rect = { -100, -100, 15, 15 };
    bool doRender;

    Bullet();

    void render(SDL_Renderer *renderer);

    void setPos(float _x, float _y);

    void setVel(float _velX, float _velY);

};
