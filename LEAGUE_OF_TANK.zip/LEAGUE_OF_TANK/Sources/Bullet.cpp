#include "Bullet.h"

Bullet::Bullet()
{
    x = -100;
    y = -100;
    velX = 0;
    velY = 0;
    doRender = false;
}

void Bullet::render(SDL_Renderer *renderer)
{
        if (doRender)
            texture.render(renderer, x, y);
}

void Bullet::setPos(float _x, float _y)
{
    x = _x;
    y = _y;
    rect.x = x;
    rect.y = y;
}

void Bullet::setVel(float _velX, float _velY)
{
    velX = _velX;
    velY = _velY;
}
