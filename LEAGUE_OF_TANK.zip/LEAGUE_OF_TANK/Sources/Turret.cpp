#include "Turret.h"

Turret::Turret()
{
    HP = DEFAULT_HP;

}
void Turret::setPos(int _x, int _y)
{
    x = _x;
    y = _y;
    rect.x = x;
    rect.y = y;
}


void Turret::render(SDL_Renderer *renderer)
{
    if (HP > 0)
    {
        texture.render(renderer, x, y);
    }
    else
    {
        brokenTexture.render(renderer, x, y);
    }


    HPRect.w = HP * HPBar.getWidth() / DEFAULT_HP ;
    HPBar.render(renderer, x + (texture.getWidth() - HPBar.getWidth()) / 2, y - 20, &HPRect);
    HPFrame.render(renderer, x + (texture.getWidth() - HPBar.getWidth()) / 2, y - 20);

}

void Turret::setTexture(LTexture *_texture, LTexture *_brokenTexture)
{
    texture = *_texture;
    rect.w = texture.getWidth();
    rect.h = texture.getHeight();

    brokenTexture = *_brokenTexture;
}
void Turret::decreaseHP(float amount)
{
    HP -= amount;
    if (HP < 0) HP = 0;
}

SDL_Rect Turret::getRect()
{
    return rect;
}

float Turret::getHP()
{
    return HP;
}

void Turret::setAttackRange(SDL_Rect range)
{
    attackRange = range;
}

SDL_Rect Turret::getRange()
{
    return attackRange;
}

void Turret::setHPBarTexture(LTexture &_HPBar, LTexture &_HPFrame)
{
    HPBar = _HPBar;
    HPFrame = _HPFrame;

    HPRect.x = 0;
    HPRect.y = 0;
    HPRect.h = HPBar.getHeight();
}

void Turret::reset()
{
    HP = DEFAULT_HP;
}
