#pragma once


#include "SDL2/SDL.h"
#include "VectorAndCircle.h"

bool checkCollision(SDL_Rect a, SDL_Rect b);

float distanceSquared(int x1, int y1, int x2, int y2);
bool checkCollision(Circle& a, Circle &b);
bool checkCollision(Circle& a, SDL_Rect& b);

