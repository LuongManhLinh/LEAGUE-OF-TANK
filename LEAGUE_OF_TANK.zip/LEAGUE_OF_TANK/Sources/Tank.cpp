#include "Tank.h"
using namespace std;


float LV_ARMOR[4] = {0, 5, 10, 15};
Uint16 LV_NUMBER_BULLET[4] = {20, 30, 40, 50};
Uint16 LV_MAX_BULLET_IN_STORAGE[4] = {100, 150, 200, 250};
int LV_TANK_VEL[4] = {200, 250, 300, 360};
Uint32 LV_TIME_DELAY_RELOAD[4] = {4000, 3000, 2500, 1500};
Uint32 LV_TIME_DELAY_SHOOT[4] = {800, 500, 250, 125};
float LV_DAMAGE[4] = {1, 2, 3, 5};

Material::Material()
{
    iron = 0;
    titan = 0;
    sulfur = 0;
}
Material::Material(Uint8 iron, Uint8 titan, Uint8 sulfur)
{
    this->iron = iron;
    this->titan = titan;
    this->sulfur = sulfur;
}

Material UPGRADE_MATERIAL[8][4]
{
{},
{Material(0, 0, 0), Material(20, 0, 0), Material(40, 0, 0), Material(60, 0, 0) },//Armor
{Material(0, 0, 0), Material(15, 0, 0), Material(25, 0, 0), Material(36, 0, 0) },//Number bullet
{Material(0, 0, 0), Material(15, 0, 0), Material(25, 0, 0), Material(36, 0, 0) },//Max bullet in storage
{Material(0, 0, 0), Material(20, 35, 0), Material(25, 55, 0), Material(50, 75, 0) },//Tank velocity
{Material(0, 0, 0), Material(0, 15, 0), Material(0, 27, 0), Material(0, 40, 0) },//Time delay reload
{Material(0, 0, 0), Material(0, 24, 20), Material(0, 48, 40), Material(0, 76, 50) },//Time delay shoot
{Material(0, 0, 0), Material(0, 0, 40), Material(0, 0, 60), Material(0, 0, 100) } //Damage
};

Tank::Tank()
{
    x = -100;
    y = -100;

    velX = 0;
    velY = 0;

    checkFirstKey = false;


    bottomAngle = 0;
    upAngle = 0;
    spinPoint.x = 20;
    spinPoint.y = 25;


    bulletDirect.x = 1;
    bulletDirect.y = 0;


    //set up starting indicators
    lvArmor = 0;
    lvNumberBullet = 0;
    lvMaxBulletInStorage = 0;
    lvTankVel = 0;
    lvTImeDelayReload = 0;
    lvTimeDelayShoot = 0;
    lvDamage = 0;

    MAX_ARMOR = LV_ARMOR[lvArmor];
    NUMBER_BULLET = LV_NUMBER_BULLET[lvNumberBullet];
    MAX_BULLET_IN_STORAGE = LV_MAX_BULLET_IN_STORAGE[lvMaxBulletInStorage];
    TANK_VEL = LV_TANK_VEL[lvTankVel];
    TIME_DELAY_RELOAD = LV_TIME_DELAY_RELOAD[lvTImeDelayReload];
    TIME_DELAY_SHOOT = LV_TIME_DELAY_SHOOT[lvTimeDelayShoot];
    DAMAGE = LV_DAMAGE[lvDamage];
    //

    for (Uint16 i = 0; i < LV_NUMBER_BULLET[3]; i++)
    {
        tankBullets.push_back(Bullet());

    }

    bulletIndex = 0;
    availableBullet = NUMBER_BULLET;
    bulletInStorage = MAX_BULLET_IN_STORAGE;

    allowShoot = true;
    allowReloading = true;
    allowMove = true;

    isReloading = false;
    isDead = false;
    isPlaying = false;

    diedByWater = false;

    tankRect.x = x;
    tankRect.y = y;
    tankRect.w = TANK_WIDTH;
    tankRect.h = TANK_HEIGHT;

    MAX_TANK_HP = 10;
    HP = MAX_TANK_HP;
    ARMOR = MAX_ARMOR;


    upgradeIndex = 0;
    openUpgradeTable = false;
    for (int i = 0; i < 8; i++)
    {
        upgradeRequest[i] = false;
        enoughMaterial[i] = false;
    }

    DEAD_TIME = 3000;

    capacity = 0;
    bringingIron = 0;
    bringingTitan = 0;
    bringingSulfur = 0;

    storedIron = 0;
    storedTitan = 0;
    storedSulfur = 0;

    isStealed = false;

    damageIndex = 0;
    for (int i = 0; i < 3; i++)
    {
        sectionRendered[i] = 0;
        damageRenderPosX[i] = -100;
        damageRenderPosY[i] = -100;
    }

    kills = 0;
    deaths = 0;
    //AI
    numberPoint = 0;

}

void Tank::setRenderer(SDL_Renderer *_renderer)
{
    renderer = _renderer;
}

void Tank::setFont(TTF_Font *gFont)
{
    tFont = gFont;
}

void Tank::setTextures(LTexture up[], LTexture& down, LTexture broken[])
{
    for (int i = 0; i < 4; i++)
    {
        upTexture[i] = up[i];
        upBrokenTexture[i] = broken[i];
    }
    downTexture = down;
}

void Tank::setBulletTexture(LTexture texture[])
{
    for (int i = 0; i < 4; i++)
    {
        bulletTexture[i] = texture[i];
    }
    for (Uint16 i = 0; i < LV_NUMBER_BULLET[3]; i++)
    {
        tankBullets[i].texture = bulletTexture[lvDamage];
    }
}

void Tank::setFumeTexture(LTexture fume[])
{
    for (int i = 0; i < 5; i++)
    {
        fumeTexture[i] = fume[i];
    }
}

void Tank::handleEvent(SDL_Event& e)
{
if (isPlaying)
{
    if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        checkFirstKey = true;
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {

            case SDLK_w:
                velY -= TANK_VEL;
                if (bottomAngle == 180 || bottomAngle == 0)
                {
                    if (allowMove)
                    bottomAngle = 270;
                }
                break;

            case SDLK_s:
                velY += TANK_VEL;

                if (bottomAngle == 0 || bottomAngle == 180)
                {
                    if (allowMove)
                    bottomAngle = 90;
                }
                break;

            case SDLK_a:
                velX -= TANK_VEL;
                if (bottomAngle == 90 || bottomAngle == 270)
                {
                    if (allowMove)
                    bottomAngle = 180;
                }
                break;

            case SDLK_d:
                velX += TANK_VEL;
                if (bottomAngle == 90 || bottomAngle == 270)
                {
                    if (allowMove)
                    bottomAngle = 0;
                }
                break;

            case SDLK_p:
                storedIron += 100;
                storedTitan += 100;
                storedSulfur += 100;
                break;

        }

        //upgrades event
        if (checkCollision(tankRect, storageRect) || isDead)
        {
            if (e.key.keysym.sym == SDLK_r)
            {
                openUpgradeTable = !openUpgradeTable;
            }

            if (openUpgradeTable)
            {
                switch(e.key.keysym.sym)
                {
                    case SDLK_1:
                            upgradeIndex = 1;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_2:
                            upgradeIndex = 2;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_3:
                            upgradeIndex = 3;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_4:
                            upgradeIndex = 4;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_5:
                            upgradeIndex = 5;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_6:
                            upgradeIndex = 6;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_7:
                            upgradeIndex = 7;
                            Mix_PlayChannel(-1, buttonSound, 0);
                    break;

                    case SDLK_RETURN:
                    upgradeRequest[upgradeIndex] = true;
                    break;

                }

            }
        }
        else
        {
            openUpgradeTable = false;
            upgradeIndex = 0;
        }
        //

    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 && checkFirstKey )
    {
        //Adjust the velocity

        switch( e.key.keysym.sym )
        {
            case SDLK_w: velY += TANK_VEL; break;
            case SDLK_s: velY -= TANK_VEL; break;
            case SDLK_a: velX += TANK_VEL; break;
            case SDLK_d: velX -= TANK_VEL; break;
        }
    }

    //spin the up part
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_KEYDOWN)
    {
        SDL_GetMouseState(&mX, &mY);
    }

    int spinX = spinPoint.x + x;
    int spinY = spinPoint.y + y;

    bulletDirect.x = mX - spinX;
    bulletDirect.y = mY - spinY;
    float lengthFromMouse = bulletDirect.getLength();

    shootPoint.x = bulletDirect.x * 50 / lengthFromMouse + spinX;
    shootPoint.y = bulletDirect.y * 50 / lengthFromMouse + spinY;

    if (!isDead)
    {
        double anglePi = acos(bulletDirect.x / lengthFromMouse);
        double angle = anglePi / pi * 180;
        if (kiemTraGocVector(bulletDirect) == I || kiemTraGocVector(bulletDirect) == II)
        {
            upAngle = angle;
        }
        else
        {
            upAngle = 360 - angle;
        }
    }

    //shoot event
     if (shootTimer.getTicks() >= TIME_DELAY_SHOOT)
    {
        shootTimer.stop();
        if (!isDead && !isReloading)
        {
            allowShoot = true;
            //allowReloading = true;
        }
    }

    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT)
    {
        if (availableBullet > 0 && allowShoot)
        {
            bulletIndex++;
            availableBullet --;

            if (bulletIndex >= NUMBER_BULLET)
            {
                bulletIndex = 0;
            }

            tankBullets[bulletIndex].setPos(shootPoint.x, shootPoint.y);
            tankBullets[bulletIndex].doRender = true;

            double rate = BULLET_VEL / bulletDirect.getLength();
            tankBullets[bulletIndex].setVel(rate * bulletDirect.x, rate *  bulletDirect.y);

            allowShoot = false;
            //allowReloading = false;
            shootTimer.start();

            Mix_PlayChannel(-1, shootSound, 0);
        }
        if (availableBullet == 0)
        {
            Mix_PlayChannel(-1, runOutOfBulletSound, 0);
        }
    }

    if (shootTimer.getTicks() >= TIME_DELAY_SHOOT)
    {
        shootTimer.stop();
        if (!isDead)
        {
            allowShoot = true;
        }
    }

 //reload bullet

    if (bulletInStorage > 0 && availableBullet < NUMBER_BULLET && allowReloading)
    {
        if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_RIGHT)
        {
             reloadTimer.start();
             allowReloading = false;
             allowShoot = false;
             isReloading = true;

             Mix_PlayChannel(-1, reloadingSound, 0);

        }
    }

    if (reloadTimer.getTicks() >= TIME_DELAY_RELOAD)
    {
        int reloadBullet = NUMBER_BULLET - availableBullet;
         if (reloadBullet > bulletInStorage)
         {
             reloadBullet = bulletInStorage;
         }
         availableBullet += reloadBullet;
         bulletInStorage -= reloadBullet;

        reloadTimer.stop();
        isReloading = false;
        bulletIndex = 0;
        if (!isDead)
        {
            allowShoot = true;
            allowReloading = true;

        }
    }

}

}
void Tank:: move(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, vector<ArrayIndex>& river, vector <Tank> &enemies, float& time, Ore& iron, Ore& titan, Ore& sulfur)
{
    if(!isDead)
    {
        float preX = x;
        x += time * velX;
        tankRect.x = x;

        for (Uint8 index = 0; index < enemies.size(); index++)
        {
            if (checkCollision(tankRect, enemies[index].getRect()))
            {
               x = preX;
               tankRect.x = x;

               if (enemies[index].getHP() == 0 && !enemies[index].isStealed)
                {
                    if (capacity < MAX_CAPACITY)
                    {
                        int tempIron = 5 + rand() % 6;
                        int tempTitan = 5 + rand() % 6;
                        int tempSulfur = 4 + rand() % 5;

                        capacity += tempIron + tempTitan + tempSulfur;

                        bringingIron += tempIron;
                        bringingTitan += tempTitan;
                        bringingSulfur += tempSulfur;

                        enemies[index].isStealed =  true;
                    }

                    HP += 5;
                    if (HP > MAX_TANK_HP)
                    {
                        HP = MAX_TANK_HP;
                    }

                    Mix_PlayChannel (-1, takeOreSound, 0);
                }

                if (enemies[index].getHP() <= 0)
                {
                    int preSite = enemies[index].x;
                    enemies[index].x += time * velX;
                    enemies[index].tankRect.x = enemies[index].x;

                    for (ArrayIndex wall : walls)
                    {
                        if (checkCollision(enemies[index].tankRect, block[wall.x][wall.y].block))
                        {
                            enemies[index].x = preSite;
                            enemies[index].tankRect.x = enemies[index].x;
                        }
                    }
                }
            }
        }

        for (ArrayIndex wall : walls)
        {
            if (checkCollision(tankRect, block[wall.x][wall.y].block))
            {
                x = preX;
                tankRect.x = x;
            }
        }

        for (int i = 0; i < NUMBER_IRON; i++)
        {
            if (checkCollision(tankRect, iron.getRect(i)))
            {
                if (iron.getHP(i) > 0)
                {
                    x = preX;
                    tankRect.x = x;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        iron.beTaken(i);

                        numberOreGot = rand() % 3 + 6;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingIron += numberOreGot;
                    }
                }
            }
        }

        for (int i = 0; i < NUMBER_TITAN; i++)
        {
            if (checkCollision(tankRect, titan.getRect(i)))
            {
                if (titan.getHP(i) > 0)
                {
                    x = preX;
                    tankRect.x = x;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        titan.beTaken(i);

                        numberOreGot = rand() % 3 + 6;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingTitan += numberOreGot;
                    }
                }
            }
        }

        for (int i = 0; i < NUMBER_SULFUR; i++)
        {
            if (checkCollision(tankRect, sulfur.getRect(i)))
            {
                if (sulfur.getHP(i) > 0)
                {
                    x = preX;
                    tankRect.x = x;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        sulfur.beTaken(i);

                        numberOreGot = rand() % 3 + 5;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingSulfur += numberOreGot;
                    }
                }
            }
        }



        float preY = y;
        y += time * velY;
        tankRect.y = y;

        for (Uint8 index = 0; index < enemies.size(); index++)
        {
            if (checkCollision(tankRect, enemies[index].getRect()))
            {

                y = preY;
                tankRect.y = y;

               if (enemies[index].getHP() == 0 && !enemies[index].isStealed)
                {
                    if (capacity < MAX_CAPACITY)
                    {
                        int tempIron = 5 + rand() % 6;
                        int tempTitan = 5 + rand() % 6;
                        int tempSulfur = 4 + rand() % 5;

                        capacity += tempIron + tempTitan + tempSulfur;

                        bringingIron += tempIron;
                        bringingTitan += tempTitan;
                        bringingSulfur += tempSulfur;

                        enemies[index].isStealed =  true;
                    }

                    HP += 5;
                    if (HP > MAX_TANK_HP)
                    {
                        HP = MAX_TANK_HP;
                    }

                    Mix_PlayChannel (-1, takeOreSound, 0);
                }

                if (enemies[index].getHP() <= 0)
                {
                    int preSite = enemies[index].y;
                    enemies[index].y += time * velY;
                    enemies[index].tankRect.y = enemies[index].y;

                    for (ArrayIndex wall : walls)
                    {
                        if (checkCollision(enemies[index].tankRect, block[wall.x][wall.y].block))
                        {
                            enemies[index].y = preSite;
                            enemies[index].tankRect.y = enemies[index].y;;
                        }
                    }


                }
            }
        }

        for (ArrayIndex wall : walls)
        {
            if (checkCollision(tankRect, block[wall.x][wall.y].block))
            {
                y = preY;
                tankRect.y = y;
            }
        }

         for (int i = 0; i < NUMBER_IRON; i++)
        {
            if (checkCollision(tankRect, iron.getRect(i)))
            {
                if (iron.getHP(i) > 0)
                {
                    y = preY;
                    tankRect.y = y;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        iron.beTaken(i);

                        numberOreGot = rand() % 3 + 3;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingIron += numberOreGot;
                    }
                }
            }
        }

        for (int i = 0; i < NUMBER_TITAN; i++)
        {
            if (checkCollision(tankRect, titan.getRect(i)))
            {
                if (titan.getHP(i) > 0)
                {
                    y = preY;
                    tankRect.y = y;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        titan.beTaken(i);

                        numberOreGot = rand() % 3 + 3;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingTitan += numberOreGot;
                    }
                }
            }
        }

        for (int i = 0; i < NUMBER_SULFUR; i++)
        {
            if (checkCollision(tankRect, sulfur.getRect(i)))
            {
                if (sulfur.getHP(i) > 0)
                {
                    y = preY;
                    tankRect.y = y;
                }
                else
                {

                    if (capacity < MAX_CAPACITY)
                    {
                        Mix_PlayChannel (-1, takeOreSound, 0);
                        sulfur.beTaken(i);

                        numberOreGot = rand() % 3 + 3;
                        capacity += numberOreGot;
                        if (capacity > MAX_CAPACITY)
                        {
                            numberOreGot = numberOreGot - (capacity - MAX_CAPACITY);
                            capacity = MAX_CAPACITY;
                        }

                        bringingSulfur += numberOreGot;
                    }
                }
            }
        }

        int touchWater = 0;
        for (ArrayIndex water : river)
        {
            if (checkCollision(tankRect, block[water.x][water.y].block))
            {
                touchWater++;
                if (touchWater == 4)
                {
                    decreaseHP(100);
                    diedByWater = true;
                    Mix_VolumeChunk(takeDamageSound, MIX_MAX_VOLUME * 2);
                    Mix_PlayChannel (-1, takeDamageSound, 0);
                    break;
                }
            }
        }

        if (checkCollision(tankRect, storageRect))
        {
            storedIron += bringingIron;
            storedTitan += bringingTitan;
            storedSulfur += bringingSulfur;

            capacity = 0;
            bringingIron = 0;
            bringingTitan = 0;
            bringingSulfur = 0;

            bulletInStorage = MAX_BULLET_IN_STORAGE;

            if (ARMOR < MAX_ARMOR)
            {
                ARMOR = MAX_ARMOR;
            }
            if (HP < MAX_TANK_HP)
            {
                HP = MAX_TANK_HP;
            }
        }

    }

}

void Tank::doShoot(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, vector <Tank> &enemies, float& time, Ore& iron, Ore& titan, Ore& sulfur)
{

    for (int i = 0; i < NUMBER_BULLET; i++)
    {
        tankBullets[i].x += time * tankBullets[i].velX;
        tankBullets[i].y += time * tankBullets[i].velY;
        tankBullets[i].rect.x = tankBullets[i].x;
        tankBullets[i].rect.y = tankBullets[i].y;

            int numberKills = 0;

            for (Uint8 index = 0; index < enemies.size(); index++)
            {
                if (checkCollision(tankBullets[i].rect, enemies[index].getRect()))
                {
                    if (enemies[index].getHP() > 0 && enemies[index].getArmor() == 0)
                    {
                        Mix_VolumeChunk(takeDamageSound, (SCREEN_HEIGHT  - bulletDirect.getLength() ) * MIX_MAX_VOLUME / SCREEN_HEIGHT);
                        Mix_PlayChannel (-1, takeDamageSound, 0);
                    }
                    else if (enemies[index].getHP() > 0 && enemies[index].getArmor() > 0)
                    {
                        Mix_VolumeChunk(takeDamageSound, (SCREEN_HEIGHT  - bulletDirect.getLength() ) * MIX_MAX_VOLUME / SCREEN_HEIGHT);
                        Mix_PlayChannel (-1, armorSound, 0);
                    }


                    enemies[index].decreaseHP(DAMAGE);
                    enemies[index].beAlerted();
                    tankBullets[i].doRender = false;

                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    break;
                }

                else
                {
                    for (Uint8 index2 = 1; index2 < 3; index2++)
                    {
                        if (checkCollision(tankBullets[i].rect, enemies[0].turret[index2].getRect()))
                        {
                            enemies[0].decreaseTurretHP(DAMAGE , index2);

                            tankBullets[i].doRender = false;
                            tankBullets[i].setPos(-100, -100);
                            tankBullets[i].setVel(0, 0);
                            break;
                        }

                    }

                    if (enemies[0].turret[1].getHP() == 0 && enemies[0].turret[2].getHP() == 0)
                    {
                        if (checkCollision( tankBullets[i].rect, enemies[0].turret[0].getRect() ))
                        {
                            enemies[0].decreaseTurretHP(DAMAGE / (5 - lvDamage), 0);

                            tankBullets[i].doRender = false;
                            tankBullets[i].setPos(-100, -100);
                            tankBullets[i].setVel(0, 0);
                            break;
                        }
                    }
                }

                numberKills += enemies[index].deaths;
            }

            kills = numberKills;

            for (ArrayIndex wall : walls)
            {
                if (checkCollision(tankBullets[i].rect, block[wall.x][wall.y].block))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    break;
                }


            }


            for (int j = 0; j < NUMBER_IRON; j++)
            {
                if (checkCollision(tankBullets[i].rect, iron.getRect(j)))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    iron.decreaseHP(j, DAMAGE);
                    break;
                }

            }

            for (int j = 0; j < NUMBER_TITAN; j++)
            {
                if (checkCollision(tankBullets[i].rect, titan.getRect(j)))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    titan.decreaseHP(j, DAMAGE);
                    break;
                }

            }

            for (int j = 0; j < NUMBER_SULFUR; j++)
            {
                if (checkCollision(tankBullets[i].rect, sulfur.getRect(j)))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    sulfur.decreaseHP(j, DAMAGE);
                    break;
                }

            }
        }
}

void Tank::checkStatus(Tank *enemy)
{
    if (HP <= 0 && !isDead)
    {
        deadTimer.start();
        isDead = true;
        allowShoot = false;
        allowReloading = false;
        allowMove = false;
        renderDeadTime = true;

        deaths ++;
    }
    if (deadTimer.getTicks() >= DEAD_TIME)
    {
        renderDeadTime = false;
        setPosition(respawnPoint.x, respawnPoint.y);
        if (numberPoint > 0)
        {
            passedIndex = 0;
            nextIndex = 1;
            distanceTraveled = 0;
            totalDistance = Vector(orbitPoints[nextIndex].x - orbitPoints[passedIndex].x, orbitPoints[nextIndex].y - orbitPoints[passedIndex].y).getLength();
            if (checkCollision(tankRect, enemy->tankRect))
            {
                enemy->x += abs(enemy->x - (respawnPoint.x + TANK_WIDTH));
            }
        }

        availableBullet = NUMBER_BULLET;
        bulletInStorage = MAX_BULLET_IN_STORAGE;

        deadTimer.stop();
        isDead = false;
        allowShoot = true;
        allowReloading = true;
        allowMove = true;


        diedByWater = false;

        isStealed = false;

        HP = MAX_TANK_HP;
        ARMOR = MAX_ARMOR;
    }
}

void Tank::render()
{

    if (HP > 0)
    {
        downTexture.render(renderer, x, y, NULL, bottomAngle);
        upTexture[lvArmor].render(renderer, x, y, NULL, upAngle, &spinPoint);
    }
    else
    {
        if(!diedByWater)
        {
            downTexture.render(renderer, x, y, NULL, bottomAngle);
            upBrokenTexture[lvArmor].render(renderer, x, y, NULL, upAngle, &spinPoint);
            renderFume(deadTimer.getTicks());

        }
    }

    for (int i = 0; i < NUMBER_BULLET; i++)
    {
        tankBullets[i].render(renderer);
    }

    for (Uint8 i = 0; i < turret.size(); i++)
    {
        turret[i].render(renderer);
    }

    HPRect.w = HP / MAX_TANK_HP * HPBar.getWidth();
    ArmorRect.w = ARMOR / LV_ARMOR[3] * ArmorBar.getWidth();

    HPBar.render(renderer, x - 25, y - 20, &HPRect);
    ArmorBar.render(renderer, x - 25, y - 20, &ArmorRect);
    HPFrame.render(renderer, x - 25, y - 20);

    if (renderDeadTime && isDead)
    {

        timeRect.w = (DEAD_TIME - deadTimer.getTicks() ) * timeLine.getWidth() / DEAD_TIME ;
        timeLine.render(renderer, x - 25, y - 30, &timeRect);
        if (timeRect.w == 0) renderDeadTime = false;

    }
    for (Uint8 i = 0; i < 10; i++)
    {
        if (sectionRendered[i] <= 3 * BLOCK_SIDE)
        {
            damageTexture[i].render(renderer, damageRenderPosX[i], damageRenderPosY[i]);
            sectionRendered[i] += 1;
            damageRenderPosY[i] -= 1;
        }
        else
        {
            sectionRendered[i] = 0;
            damageRenderPosX[i] = -100;
            damageRenderPosY[i] = -100;
        }

    }
}

void Tank::renderFume(Uint32 deadTime)
{
    Uint8 time = deadTime % 1001;
    fumeTexture[time / 100].render(renderer, x, y);
}

SDL_Rect Tank::getRect()
{
    return tankRect;
}

void Tank::chooseToPlay(bool yesOrNo)
{
    isPlaying = yesOrNo;
}

void Tank::decreaseHP(float amount)
{
    if (HP > 0 && amount >= 1)
    {
        string dameString = "-" + to_string ((int) amount);
        SDL_Color color;
        if (amount == LV_DAMAGE[1])
        {
            color.r = 237;
            color.g = 28;
            color.b = 26;
            color.a = 255;
        }
        else if (amount == LV_DAMAGE[2])
        {
            color.r = 255;
            color.g = 255;
            color.b = 255;
            color.a = 255;
        }
        else if (amount == LV_DAMAGE[3])
        {
            color.r = 190;
            color.g = 130;
            color.b = 255;
            color.a = 255;
        }
        else
        {
            color.r = 245;
            color.g = 228;
            color.b = 156;
            color.a = 255;
        }
        damageTexture[damageIndex].loadFromRenderedText(renderer, tFont, dameString.c_str(), color);
        damageRenderPosX[damageIndex] = x + TANK_WIDTH / 2 - damageTexture[damageIndex].getWidth() / 2;
        damageRenderPosY[damageIndex] = y  + TANK_HEIGHT / 2;
        sectionRendered[damageIndex] = 0;

        damageIndex++;
        if (damageIndex > 9)
        {
            damageIndex = 0;
        }

        ARMOR -= amount;
        if (ARMOR < 0)
        {
            HP += ARMOR;
            ARMOR = 0;
        }
        if (HP < 0) HP = 0;
    }


    if (amount < 1)
    {
        ARMOR -= amount / (lvArmor + 1);
        if (ARMOR < 0)
        {
            HP += ARMOR * (lvArmor + 1);
            ARMOR = 0;
        }
        if (HP < 0) HP = 0;
    }

}

void Tank::decreaseTurretHP(float amount, Uint8 index)
{
    turret[index].decreaseHP(amount);
}

void Tank::setRespawnPoint(SDL_Point& point)
{
    respawnPoint = point;
}

void Tank::setPosition(int _x, int _y)
{
    x = _x;
    y = _y;
    tankRect.x = x;
    tankRect.y = y;
}

void Tank::chooseTurret(vector <Turret>& imTurret)
{
    turret = imTurret;
}

void Tank::turretAttack(Tank& enemyTank, float time)
{
    SDL_Rect enemyRect = enemyTank.getRect();
    for (Uint8 i = 0; i < turret.size(); i++)
    {
        if (turret[i].getHP() > 0)
        {
            SDL_Rect turretRect = turret[i].getRect(), turretRange = turret[i].getRange();
            int turretAttackPointX = turretRect.x + turretRect.w / 2;
            int turretAttackPointY = turretRect.y + turretRect.h / 2;
            if (checkCollision(turretRange, enemyRect) && enemyTank.getHP() > 0)
            {
                SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
                SDL_RenderDrawLine(renderer,  turretAttackPointX, turretAttackPointY, enemyRect.x + enemyRect.w / 2, enemyRect.y + enemyRect.w / 2);
                enemyTank.decreaseHP(5 * time);

                Mix_PlayChannel(0, electricSound, 0);
                Mix_PlayChannel(1, electricSound, 0);
            }
        }
    }
}


vector <SDL_Rect> Tank::getTurretRect()
{
   vector <SDL_Rect> rects;
   for (Uint8 i = 0; i < turret.size(); i++)
   {
       rects.push_back(turret[i].getRect());
   }
   return rects;
}

float Tank::getHP()
{
    return HP;
}
float Tank::getTurretHP(Uint8 index)
{
    return turret[index].getHP();
}

bool Tank::ifIsReloading()
{
    return isReloading;
}

int Tank::getNumberAvailableBullet()
{
    return availableBullet;
}
int Tank::getNumberBulletInStorage()
{
    return bulletInStorage;
}

void Tank::setStorageRect(SDL_Rect rect)
{
    storageRect = rect;
}

void Tank::setDeadTime(Uint32 time)
{
    DEAD_TIME = time;
}

int Tank::getNumberIron()
{
    return bringingIron;
}
int Tank::getNumberTitan()
{
    return bringingTitan;
}
int Tank::getNumberSulfur()
{
    return bringingSulfur;
}

int Tank::getNumberStoredIron()
{
    return storedIron;
}
int Tank::getNumberStoredTitan()
{
    return storedTitan;
}
int Tank::getNumberStoredSulfur()
{
    return storedSulfur;
}

float Tank::getArmor()
{
    return ARMOR;
}

float Tank::getMaxArmor()
{
    return LV_ARMOR[3];
}

bool Tank::upgradeTableOpened()
{
    return openUpgradeTable;
}

void Tank::receiveUpgrades(vector <Tank>& enemies)
{
    int numberBotTank = enemies.size(), randomIndex;
    if (upgradeRequest[1] && lvArmor < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[1][lvArmor + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[1][lvArmor + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[1][lvArmor + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[1][lvArmor + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[1][lvArmor + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[1][lvArmor + 1].sulfur;

            lvArmor++;
            MAX_ARMOR = LV_ARMOR[lvArmor];
            ARMOR = MAX_ARMOR;
            upgradeRequest[1] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);

            //upgrade a random bot
            randomIndex = rand() % numberBotTank;
            if (enemies[randomIndex].lvArmor == 3)
            {
                randomIndex --;
                if (randomIndex < 0)
                {
                    randomIndex = numberBotTank - 1;
                }
            }

            enemies[randomIndex].lvArmor++;
            enemies[randomIndex].MAX_ARMOR = LV_ARMOR[enemies[randomIndex].lvArmor];
            enemies[randomIndex].ARMOR = enemies[randomIndex].MAX_ARMOR;
            enemies[randomIndex].DEAD_TIME -= 1000;
        }
        else
        {
            upgradeRequest[1] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[2] && lvNumberBullet < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[2][lvNumberBullet + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[2][lvNumberBullet + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[2][lvNumberBullet + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[2][lvNumberBullet + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[2][lvNumberBullet + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[2][lvNumberBullet + 1].sulfur;

            lvNumberBullet++;
            NUMBER_BULLET = LV_NUMBER_BULLET[lvNumberBullet];

            bulletIndex = 0;
            availableBullet = NUMBER_BULLET;
            upgradeRequest[2] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);
        }
        else
        {
            upgradeRequest[2] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[3] && lvMaxBulletInStorage < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[3][lvMaxBulletInStorage + 1].sulfur;

            lvMaxBulletInStorage++;
            MAX_BULLET_IN_STORAGE = LV_MAX_BULLET_IN_STORAGE[lvMaxBulletInStorage];
            bulletInStorage = MAX_BULLET_IN_STORAGE;
            upgradeRequest[3] = false;
            DEAD_TIME += 1000;

        Mix_PlayChannel(-1, upgradeSound, 0);
        }
        else
        {
            upgradeRequest[3] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[4] && lvTankVel < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[4][lvTankVel + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[4][lvTankVel + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[4][lvTankVel + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[4][lvTankVel + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[4][lvTankVel + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[4][lvTankVel + 1].sulfur;

            lvTankVel++;
            TANK_VEL = LV_TANK_VEL[lvTankVel];
            upgradeRequest[4] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);

            //upgrade a random bot
            randomIndex = rand() % numberBotTank;
            if (enemies[randomIndex].lvTankVel == 3)
            {
                randomIndex --;
                if (randomIndex < 0)
                {
                    randomIndex = numberBotTank - 1;
                }
            }

            enemies[randomIndex].lvTankVel++;
            enemies[randomIndex].TANK_VEL = LV_TANK_VEL[enemies[randomIndex].lvTankVel];
            enemies[randomIndex].DEAD_TIME -= 1000;

        }
        else
        {
            upgradeRequest[4] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[5] && lvTImeDelayReload < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[5][lvTImeDelayReload + 1].sulfur;

            lvTImeDelayReload++;
            TIME_DELAY_RELOAD = LV_TIME_DELAY_RELOAD[lvTImeDelayReload];
            upgradeRequest[5] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);

        }
        else
        {
            upgradeRequest[5] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[6] && lvTimeDelayShoot < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[6][lvTimeDelayShoot + 1].sulfur;

            lvTimeDelayShoot++;
            TIME_DELAY_SHOOT = LV_TIME_DELAY_SHOOT[lvTimeDelayShoot];
            upgradeRequest[6] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);

            //upgrade a random bot
            randomIndex = rand() % numberBotTank;
            if (enemies[randomIndex].lvTimeDelayShoot == 3)
            {
                randomIndex --;
                if (randomIndex < 0)
                {
                    randomIndex = numberBotTank - 1;
                }
            }

            enemies[randomIndex].lvTimeDelayShoot++;
            enemies[randomIndex].TIME_DELAY_SHOOT = LV_TIME_DELAY_SHOOT[enemies[randomIndex].lvTimeDelayShoot];
            enemies[randomIndex].DEAD_TIME -= 1000;


        }
        else
        {
            upgradeRequest[6] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

    if (upgradeRequest[7] && lvDamage < 3)
    {
        if (storedIron >= UPGRADE_MATERIAL[7][lvDamage + 1].iron &&
            storedTitan >= UPGRADE_MATERIAL[7][lvDamage + 1].titan &&
            storedSulfur >= UPGRADE_MATERIAL[7][lvDamage + 1].sulfur)
        {
            storedIron -= UPGRADE_MATERIAL[7][lvDamage + 1].iron;
            storedTitan -= UPGRADE_MATERIAL[7][lvDamage + 1].titan;
            storedSulfur -= UPGRADE_MATERIAL[7][lvDamage + 1].sulfur;

            lvDamage++;
            DAMAGE = LV_DAMAGE[lvDamage];
            for (int i = 0; i < LV_NUMBER_BULLET[3]; i++)
            {
                tankBullets[i].texture = bulletTexture[lvDamage];
            }
            upgradeRequest[7] = false;
            DEAD_TIME += 1000;

            Mix_PlayChannel(-1, upgradeSound, 0);

            //upgrade a random bot
            randomIndex = rand() % numberBotTank;
            if (enemies[randomIndex].lvDamage == 3)
            {
                randomIndex --;
                if (randomIndex < 0)
                {
                    randomIndex = numberBotTank - 1;
                }
            }

            enemies[randomIndex].lvDamage++;
            enemies[randomIndex].DAMAGE = LV_DAMAGE[enemies[randomIndex].lvDamage];
            for (int i = 0; i < LV_NUMBER_BULLET[3]; i++)
            {
                enemies[randomIndex].tankBullets[i].texture = bulletTexture[enemies[randomIndex].lvDamage];
            }
            enemies[randomIndex].DEAD_TIME -= 1000;


        }
        else
        {
            upgradeRequest[7] = false;
            Mix_PlayChannel(-1, buttonSound, 0);
        }
    }

}

Uint8 Tank::getLevel(Uint8 type)
{
    switch(type)
    {
        case 1:
        return lvArmor;
        break;

        case 2:
        return lvNumberBullet;
        break;

        case 3:
        return lvMaxBulletInStorage;
        break;

        case 4:
        return lvTankVel;
        break;

        case 5:
        return lvTImeDelayReload;
        break;

        case 6:
        return lvTimeDelayShoot;
        break;

        case 7:
        return lvDamage;
        break;
    }

    return 0;
}

int Tank::getPosX()
{
    return (int) x;
}
int Tank::getPosY()
{
    return (int) y;
}

bool Tank::isAllowShoot()
{
    return allowShoot;
}

void Tank::setHPBarTexture(LTexture &_HPBar, LTexture &_HPFrame, LTexture &_ArmorBar)
{
    HPBar = _HPBar;
    HPFrame = _HPFrame;

    HPRect.x = 0;
    HPRect.y = 0;
    HPRect.h = HPBar.getHeight();

    ArmorBar = _ArmorBar;
    ArmorRect.x = 0;
    ArmorRect.y = 0;
    ArmorRect.h = ArmorBar.getHeight();
}

void Tank::pauseAllTimer()
{
    shootTimer.pause();
    reloadTimer.pause();
    deadTimer.pause();
    alertTimer.pause();
}

void Tank::unPauseAllTimer()
{
    shootTimer.unpause();
    reloadTimer.unpause();
    deadTimer.unpause();
    alertTimer.unpause();
}

void Tank::setTimeLineTexture(LTexture &line)
{
    timeLine = line;
    timeRect.w = timeLine.getWidth();
    timeRect.h = timeLine.getHeight();
    timeRect.x = 0;
    timeRect.y = 0;

    renderDeadTime = false;
}

void Tank::setSounds(Mix_Chunk *shootSound, Mix_Chunk *takeDamageSound, Mix_Chunk *armorSound, Mix_Chunk *takeOreSound,
                      Mix_Chunk *buttonSound, Mix_Chunk *upgradeSound,  Mix_Chunk *runOutOfBulletSound, Mix_Chunk *reloadingSound )
{
    this->shootSound = shootSound;
    this->takeDamageSound = takeDamageSound;
    this->armorSound = armorSound;
    this->takeOreSound = takeOreSound;
    this->buttonSound = buttonSound;
    this->upgradeSound = upgradeSound;
    this->runOutOfBulletSound = runOutOfBulletSound;
    this->reloadingSound = reloadingSound;


    Mix_VolumeChunk (this->shootSound, MIX_MAX_VOLUME / 2);
    Mix_VolumeChunk (this->takeOreSound, MIX_MAX_VOLUME * 2);
    Mix_VolumeChunk (this->buttonSound, MIX_MAX_VOLUME * 2);
    Mix_VolumeChunk (this->runOutOfBulletSound, MIX_MAX_VOLUME / 2);
}

void Tank::setTurretSound(Mix_Chunk *electricSound)
{
    this->electricSound = electricSound;
}

void Tank::reset()
{
    x = respawnPoint.x;
    y = respawnPoint.y;

    velX = 0;
    velY = 0;

    checkFirstKey = false;

    bottomAngle = 0;
    upAngle = 0;
    spinPoint.x = 20;
    spinPoint.y = 25;


    bulletDirect.x = 1;
    bulletDirect.y = 0;


    //set up starting indicators
    lvArmor = 0;
    lvNumberBullet = 0;
    lvMaxBulletInStorage = 0;
    lvTankVel = 0;
    lvTImeDelayReload = 0;
    lvTimeDelayShoot = 0;
    lvDamage = 0;

    MAX_ARMOR = LV_ARMOR[lvArmor];
    NUMBER_BULLET = LV_NUMBER_BULLET[lvNumberBullet];
    MAX_BULLET_IN_STORAGE = LV_MAX_BULLET_IN_STORAGE[lvMaxBulletInStorage];
    TANK_VEL = LV_TANK_VEL[lvTankVel];
    TIME_DELAY_RELOAD = LV_TIME_DELAY_RELOAD[lvTImeDelayReload];
    TIME_DELAY_SHOOT = LV_TIME_DELAY_SHOOT[lvTimeDelayShoot];
    DAMAGE = LV_DAMAGE[lvDamage];
    //
    for (Uint16 i = 0; i < LV_NUMBER_BULLET[3]; i++)
    {
        tankBullets[i].texture = bulletTexture[lvDamage];
        tankBullets[i].setPos (-100, -100);
    }

    DEAD_TIME = 3000;

    bulletIndex = 0;
    availableBullet = NUMBER_BULLET;
    bulletInStorage = MAX_BULLET_IN_STORAGE;

    allowMove = true;
    allowShoot = true;

    isReloading = false;
    isDead = false;
    isPlaying = false;

    MAX_TANK_HP = 10;
    HP = MAX_TANK_HP;
    ARMOR = MAX_ARMOR;

    capacity = 0;
    bringingIron = 0;
    bringingTitan = 0;
    bringingSulfur = 0;

    storedIron = 0;
    storedTitan = 0;
    storedSulfur = 0;

    kills = 0;
    deaths = 0;

    openUpgradeTable = false;
    for (int i = 0; i < 8; i++)
    {
        upgradeRequest[i] = false;
    }

    shootTimer.stop();
    reloadTimer.stop();
    deadTimer.stop();
    alertTimer.stop();
}

int Tank::getKills()
{
    return kills;
}
int Tank::getDeaths()
{
    return deaths;
}
