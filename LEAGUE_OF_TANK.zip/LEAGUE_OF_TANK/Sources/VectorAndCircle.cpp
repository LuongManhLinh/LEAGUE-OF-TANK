
#include "VectorAndCircle.h"

Vector::Vector(){};
Vector::Vector(float _x = 0, float _y = 0)
{
    x = _x;
    y = _y;
}

float Vector::getLength()
{
    return sqrt(x * x + y * y);
}

Vector project(Vector a, Vector other)
{
    double rate = (a.x * other.x + a.y * other.y) / pow(other.getLength(), 2);

    return Vector(other.x * rate, other.y * rate);
}

Vector vecAdd(Vector a, Vector b)
{
    return Vector(a.x + b.x, a.y + b.y);
}

Vector vecMinus(Vector a, Vector b)
{
    return Vector(a.x - b.x, a.y - b.y);
}

float Vector::getAngleToOx()
{
    return acos(x / getLength()) / 3.14159 * 180;
}


gocPhanTu kiemTraGocVector(Vector vct)
{
    if (vct.x > 0 && vct.y >= 0) return I;
    if (vct.x <= 0 && vct.y > 0) return II;
    if (vct.x < 0 && vct.y <= 0) return III;
    return IV;
}

ArrayIndex::ArrayIndex(int _x = -1, int _y = -1)
{
    x = _x;
    y = _y;
}
