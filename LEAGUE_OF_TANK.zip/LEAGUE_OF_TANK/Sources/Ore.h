#pragma once

#include "iostream"
#include "VectorAndCircle.h"
#include "fstream"
#include "LTexture.h"
#include "LTimer.h"
#include "constant.h"
#include "vector"
#include "checkCollision.h"

class Ore
{
    public:

        const static Uint32 RESPAWN_TIME = 120000;
        const static Uint32 WAIT_FOR_TAKING_TIME = 10000;

        Ore(int n);

        void setHP (float _HP);
        void decreaseHP (int index, float amount);

        void setRandomPos(vector <ArrayIndex> _randomPos);
        void setTexture(LTexture &rawTexture, LTexture &lootTexture);

        void checkStatus(vector <SDL_Rect> &tankRects);

        void render(SDL_Renderer *renderer);


        SDL_Rect getRect(int index);

        void beTaken(int index);

        float getHP(int index);

        void clear();

        void reset();

        void setSound (Mix_Chunk *takeDameSound, Mix_Chunk *brokenSound);

    private:
        int number;

        float *HP;
        float MAX_HP;

        vector<ArrayIndex> allPos, pos;
        vector <int> notContainOre;
        vector <int> containOre;
        SDL_Rect *rect;
        LTexture* rawTexture, *lootTexture;

        LTimer *respawnTimer;
        LTimer *waitForTakingTimer;

        bool *isTaken;

        Mix_Chunk *takeDameSound, *brokenSound;
        bool playTakeDameSound, playBrokenSound;

};

