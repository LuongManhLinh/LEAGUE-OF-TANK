#include "Tank.h"

//AI
void Tank::AI_setOrbit(vector <SDL_Point> &setPoints)
{
    orbitPoints = setPoints;
    numberPoint = orbitPoints.size();
    passedIndex = 0;
    distanceTraveled = 0;

    x = orbitPoints[0].x;
    y = orbitPoints[0].y;
    tankRect.x = x;
    tankRect.y = y;

    respawnPoint = orbitPoints[0];

    enemyDetected = false;

    changeAllowMoveWhileShooting = true;

    if (numberPoint <= 1)
    {
        moveDirection.x = 0;
        moveDirection.y = 0;
    }
    else
    {
        nextIndex = 1;
        totalDistance = Vector(orbitPoints[nextIndex].x - orbitPoints[passedIndex].x, orbitPoints[nextIndex].y - orbitPoints[passedIndex].y).getLength();
        isTurningBack = false;
    }

}

void Tank::AI_setAlertRange(vector <SDL_Rect>& range)
{
    alertRange = range;
}

void Tank::AI_move(float &time, Tank& enemy)
{
    if (numberPoint > 1 && allowMove)
    {
        moveDirection = Vector(orbitPoints[nextIndex].x - orbitPoints[passedIndex].x, orbitPoints[nextIndex].y - orbitPoints[passedIndex].y);
        float rate = TANK_VEL / moveDirection.getLength();
        velX =  rate * moveDirection.x;
        velY =  rate * moveDirection.y;

        x += velX * time;
        y += velY * time;

        distanceTraveled += sqrt(pow(velX * time, 2) + pow(velY * time, 2));

        tankRect.x = x;
        tankRect.y = y;

        bottomAngle = moveDirection.getAngleToOx();
        if (kiemTraGocVector(moveDirection) == III || kiemTraGocVector(moveDirection) == IV)
        {
            bottomAngle = 360 - bottomAngle;
        }

        if (checkCollision(tankRect, enemy.getRect()))
        {
             x -= velX * time;
             y -= velY * time;

             distanceTraveled -= sqrt(pow(velX * time, 2) + pow(velY * time, 2));
        }


            if (!isTurningBack)
            {

            if (abs (distanceTraveled - totalDistance) <= 5)
            {
                passedIndex = nextIndex;
                nextIndex ++;

                if (nextIndex == numberPoint)
                {
                    nextIndex = nextIndex - 2;
                    isTurningBack = true;

                }

                distanceTraveled = 0;
                totalDistance = Vector(orbitPoints[nextIndex].x - orbitPoints[passedIndex].x, orbitPoints[nextIndex].y - orbitPoints[passedIndex].y).getLength();

            }

        }

        else
        {
            if ( abs (distanceTraveled - totalDistance) <= 5 )
            {
                passedIndex = nextIndex;
                nextIndex --;

                if (nextIndex < 0)
                {
                    nextIndex = 1;
                    isTurningBack = false;
                }

                distanceTraveled = 0;
                totalDistance = Vector(orbitPoints[nextIndex].x - orbitPoints[passedIndex].x, orbitPoints[nextIndex].y - orbitPoints[passedIndex].y).getLength();
            }
        }

    }
}

void Tank::AI_checkEnemy(Tank& enemy)
{
    SDL_Rect enemyRect = enemy.getRect();

    if (HP > 0)
    {
        upAngle += 1;
        if (upAngle == 360)
        {
             upAngle = 0;
        }
    }

        for (SDL_Rect workingRect : alertRange)
        {
            if (checkCollision(workingRect, enemyRect) && enemy.getHP() > 0)
            {
                enemyDetected = true;
                alertTimer.start();
                break;
            }
        }

        if (enemyDetected && !isDead && enemy.getHP() > 0)
        {
            SDL_Point enemyMidPoint =  {enemyRect.x + enemyRect.w / 2, enemyRect.y + enemyRect.h / 2};

            if (changeAllowMoveWhileShooting)
            {
                allowMove = rand() % 2;
                changeAllowMoveWhileShooting = false;
            }
            int spinX = x + spinPoint.x;
            int spinY = y + spinPoint.y;
            bulletDirect.x = enemyMidPoint.x - spinX;
            bulletDirect.y = enemyMidPoint.y - spinY;

            shootPoint.x = bulletDirect.x * 50 / bulletDirect.getLength() + spinX;
            shootPoint.y = bulletDirect.y * 50 / bulletDirect.getLength() + spinY;

            double anglePi = acos(bulletDirect.x / bulletDirect.getLength());
            double angle = anglePi / pi * 180;
            if (kiemTraGocVector(bulletDirect) == I || kiemTraGocVector(bulletDirect) == II)
            {
                upAngle = angle;
            }
            else
            {
                upAngle = 360 - angle;
            }

             if (shootTimer.getTicks() >= TIME_DELAY_SHOOT)
            {
                shootTimer.stop();

                if (!isDead)
                {
                    allowShoot = true;
                }
            }

            if ( allowShoot)
            {
                bulletIndex++;

                if (bulletIndex >= NUMBER_BULLET)
                {
                    bulletIndex = 0;
                }

                tankBullets[bulletIndex].setPos(shootPoint.x, shootPoint.y);
                tankBullets[bulletIndex].doRender = true;

                double rate = BULLET_VEL / bulletDirect.getLength();
                tankBullets[bulletIndex].setVel(rate * bulletDirect.x, rate *  bulletDirect.y);

                allowShoot = false;
                shootTimer.start();

                Mix_VolumeChunk(shootSound, (SCREEN_HEIGHT  - bulletDirect.getLength() ) * MIX_MAX_VOLUME / SCREEN_HEIGHT);
                Mix_PlayChannel(-1, shootSound, 0);
            }

        }

        else if (!isDead)
        {
            allowMove = true;
        }

        if (alertTimer.getTicks() >= ALERT_TIME)
        {
            enemyDetected = false;
            alertTimer.stop();
            changeAllowMoveWhileShooting = true;
        }

}

void Tank::beAlerted()
{
    enemyDetected =  true;
    alertTimer.start();
}

void Tank::AI_shoot(MapByBlock block[][NUMBER_BLOCK_WIDTH], vector<ArrayIndex>& walls, Tank& enemy, float& time, Ore& iron, Ore& titan, Ore& sulfur)
{
        for (int i = 0; i < NUMBER_BULLET; i++)
        {
            tankBullets[i].x += time * tankBullets[i].velX;
            tankBullets[i].y += time * tankBullets[i].velY;
            tankBullets[i].rect.x = tankBullets[i].x;
            tankBullets[i].rect.y = tankBullets[i].y;

            if (checkCollision(tankBullets[i].rect, enemy.getRect()))
            {
                if (enemy.getHP() > 0 && enemy.getArmor() == 0)
                {
                    Mix_PlayChannel (-1, takeDamageSound, 0);
                }
                else if (enemy.getHP() > 0 && enemy.getArmor() > 0)
                {
                    Mix_PlayChannel (-1, armorSound, 0);
                }
                enemy.decreaseHP(DAMAGE);
                beAlerted();

                tankBullets[i].doRender = false;
                tankBullets[i].setPos(-100, -100);
                tankBullets[i].setVel(0, 0);
            }


            for (ArrayIndex wall : walls)
            {
                if (checkCollision(tankBullets[i].rect, block[wall.x][wall.y].block))
                {

                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    break;
                }

            }


            for (int j = 0; j < NUMBER_IRON; j++)
            {
                if (checkCollision(tankBullets[i].rect, iron.getRect(j)))
                {

                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    iron.decreaseHP(j, DAMAGE);
                    break;
                }
            }

            for (int j = 0; j < NUMBER_TITAN; j++)
            {
                if (checkCollision(tankBullets[i].rect, titan.getRect(j)))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    titan.decreaseHP(j, DAMAGE);
                    break;
                }
            }

            for (int j = 0; j < NUMBER_SULFUR; j++)
            {
                if (checkCollision(tankBullets[i].rect, sulfur.getRect(j)))
                {
                    tankBullets[i].doRender = false;
                    tankBullets[i].setPos(-100, -100);
                    tankBullets[i].setVel(0, 0);
                    sulfur.decreaseHP(j, DAMAGE);
                    break;
                }
            }
        }


}

void Tank::AI_increasePower(Uint32 GAME_TIME)
{
    int second = GAME_TIME / 1000;
    int minute = second / 60;
    if (doIncreasePower && !isDead && !enemyDetected)
    {
        MAX_TANK_HP = 10 + minute / 2;
        doIncreasePower = false;
    }
    else
    {
        doIncreasePower = true;
    }

    if (second % 60 == 0 && !isDead && !enemyDetected)
    {
        HP = MAX_TANK_HP;
    }
}

void Tank::AI_reset()
{
    orbitPoints.clear();

    enemyDetected = false;

    velX = 0;
    velY = 0;

    isDead = false;

    lvArmor = 0;
    lvTankVel = 0;
    lvTimeDelayShoot = 0;
    lvDamage = 0;

    MAX_ARMOR = LV_ARMOR[lvArmor];
    TANK_VEL = LV_TANK_VEL[lvTankVel];
    TIME_DELAY_SHOOT = LV_TIME_DELAY_SHOOT[lvTimeDelayShoot];
    DAMAGE = LV_DAMAGE[lvDamage];

    for (Uint16 i = 0; i < LV_NUMBER_BULLET[3]; i++)
    {
        tankBullets[i].texture = bulletTexture[lvDamage];
    }

    MAX_TANK_HP = 10;
    HP = MAX_TANK_HP;
    ARMOR = MAX_ARMOR;


    allowMove = false;

    kills = 0;
    deaths = 0;

    deadTimer.stop();
    alertTimer.stop();
}
