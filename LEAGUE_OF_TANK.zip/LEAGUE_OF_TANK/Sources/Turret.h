#pragma once

#include "VectorAndCircle.h"
#include "Bullet.h"
#include "constant.h"


class Turret
{
public:
    const static int DEFAULT_HP = 100;

    Turret();

    void setPos(int _x, int _y);
    void setTexture(LTexture *_texture, LTexture *_brokenTexture = NULL);

    void render(SDL_Renderer *renderer);
    void decreaseHP(float amount);
    SDL_Rect getRect();

    float getHP();
    void setAttackRange(SDL_Rect range);
    SDL_Rect getRange();

    void setHPBarTexture(LTexture &_HPBar, LTexture &_HPFrame);

    void reset();

private:
    int x, y;
    SDL_Rect attackRange;
    float HP;
    LTexture texture;
    LTexture brokenTexture;
    SDL_Rect rect;
    Bullet turretBullet;

    LTexture HPBar, HPFrame;
    SDL_Rect HPRect;
};
