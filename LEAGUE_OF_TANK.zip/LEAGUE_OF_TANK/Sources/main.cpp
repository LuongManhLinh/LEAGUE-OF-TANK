#include "fstream"
#include "Tank.h"
#include "Ore.h"
#include "AI_Tank.h"
#include "time.h"

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
TTF_Font *gFont = NULL;
TTF_Font *tFont = NULL;
TTF_Font *eFont = NULL;
TTF_Font *e2Font = NULL;

enum STATUSES
{
    IN_MENU,
    CHOOSE_MAP,
    CHOOSE_SIDE,
    GUIDE,
    QUIT,
    STARTED,
    LOADING,
    END_GAME_FAILED,
    END_GAME_PASSED
};

enum MAP
{
    MAP1,
    MAP2,
    MAP3
};

Tank tank;
const Uint8 numberBotTank = 7;
vector <Tank> botTank;
vector <SDL_Point> GuardOrbitsA;
vector <SDL_Rect> GuardWorkingRangesA;
vector <SDL_Point> GuardOrbitsT;
vector <SDL_Rect> GuardWorkingRangesT;
vector <Turret> AllyTurret, TreatyTurret;

//blocks and walls
MapByBlock GAME_BLOCK[NUMBER_BLOCK_HEIGHT][NUMBER_BLOCK_WIDTH];
vector <ArrayIndex> GAME_walls, GAME_river;

ifstream file_map1("Maps\\new map 1.txt");
ifstream file_map2("Maps\\new map 2.txt");
ifstream file_map3("Maps\\new map 3.txt");
MapByBlock BLOCK[3][NUMBER_BLOCK_HEIGHT][NUMBER_BLOCK_WIDTH];
vector <ArrayIndex> walls[3], river[3];

vector <ArrayIndex> ir[3], t[3], s[3];
Ore iron(NUMBER_IRON), titan(NUMBER_TITAN), sulfur(NUMBER_SULFUR);

void backToMenu();
void loadMap1();
void loadMap2();
void loadMap3();

LTimer GAME_TIMER;

bool PAUSE = false;

STATUSES GAME_STATUS = IN_MENU;
STATUSES LOADING_FOR = CHOOSE_MAP;

MAP GAME_MAP = MAP1;

bool CHOOSE_ALLY = false;
bool CHOOSE_TREATY = false;

int FlagAllyX = BLOCK_SIDE;
int FlagAllyY = BLOCK_SIDE;

int FlagTreatyX = 42 * BLOCK_SIDE;
int FlagTreatyY =  BLOCK_SIDE;


int turretAx0 = 5 * BLOCK_SIDE;
int turretAy0 = 5 * BLOCK_SIDE;
int turretAx1 = 1 * BLOCK_SIDE;
int turretAy1 = 12 * BLOCK_SIDE;
int turretAx2 = 14 * BLOCK_SIDE;
int turretAy2 = 5 * BLOCK_SIDE;

int turretTx0 = (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE;
int turretTy0 = (NUMBER_BLOCK_HEIGHT - 7) * BLOCK_SIDE;
int turretTx1 = 38 * BLOCK_SIDE;
int turretTy1 = 28 * BLOCK_SIDE;
int turretTx2 = 47 * BLOCK_SIDE;
int turretTy2 = 17 * BLOCK_SIDE;

SDL_Point spawnPointA;
SDL_Point spawnPointT;
SDL_Rect storageA;
SDL_Rect storageT;

LTexture reloadingTexture;

LTexture AllyTankUp[4];
LTexture AllyTankBot;
LTexture AllyBrokenTankUp[4] ;

LTexture TreatyTankUp[4];
LTexture TreatyTankBot;
LTexture TreatyBrokenTankUp[4];

LTexture bullet[4];

LTexture block[3][4];
       //block[type of map][type of block]
LTexture AllyFlag, TreatyFlag;

LTexture AllyTurretTexture, TreatyMainTurretTexture;
LTexture ProtectiveTurretTexture, ProtectiveTurretTexture_broken;

LTexture explosion[5], fumeTexture[5];

LTexture rawIronTexture, rawTitanTexture, rawSulfurTexture;
LTexture lootIronTexture, lootTitanTexture, lootSulfurTexture;

int tabPosX = 14 * BLOCK_SIDE;
int tabPosY =  0;
bool doRenderTab = false;
LTexture tabTexture;
LTexture numberOreText;
LTexture oreShape[3], numOreTexture[3];
LTexture levelTextures[7];

LTexture upgradeTable, materialTexture, maxLevelTexture;
bool doRenderUpgradeTable = false;
SDL_Rect boarder1 = {-1000, -1000, 300, 37}, boarder2 = {-1000, -1000, 298, 35};
int uTableX = 5 * BLOCK_SIDE;
int uTableY = 0;
int boarderIndex = 0;
LTexture numberMaterialTexture[3];
Uint16 numberMaterial[3];

LTexture chooseSideTexture;
int chooseSideX = SCREEN_WIDTH / 2 - 350;
int chooseSideY = SCREEN_HEIGHT / 2 - 200;
SDL_Rect bg = {chooseSideX, chooseSideY + 60, 700, 340};
SDL_Rect bgA = {chooseSideX, chooseSideY + 60, 350, 340};
SDL_Rect bgT = {chooseSideX + 350, chooseSideY + 60, 350, 340};
bool doRenderChooseSide = false, doRenderbgA = false, doRenderbgT = false;

LTexture abTexture, bisTexture;
LTexture numberIronTexture, numberTitanTexture, numberSulfurTexture;
LTexture timeTexture, clockTexture;
bool timeStart = true;
SDL_Rect timeBG = {51 * BLOCK_SIDE, 2 * BLOCK_SIDE, 2 * BLOCK_SIDE - 10, 2 * BLOCK_SIDE};

LTexture killsAndDeathsTexture;
SDL_Rect killsAndDeathsBG = {51 * BLOCK_SIDE , 5 * BLOCK_SIDE - 10, 0, BLOCK_SIDE};

LTexture HPFrame, HPBar, HPBarBlue, ArmorBar;

LTexture timeLine[3];

Mix_Chunk *ore_takeDameSound, *ore_brokenSound, *takeOreSound;
Mix_Chunk *tank_shootSound, *tank_takeDameSound, *tank_armorSound, *tank_reloadSound, *tank_runOutOfBulletSound;
Mix_Chunk *bot_shootSound[numberBotTank], *bot_takeDameSound[numberBotTank], *bot_armorSound[numberBotTank];

Mix_Chunk *buttonSound, *upgradeSound;


Mix_Chunk *electricSound;

//menu parts
const Uint8 numberButton = 4;
LTexture menuTexture;
LTexture menuParts[numberButton];
SDL_Rect menuRects[numberButton];
bool inMenuPart[numberButton], chooseMenuPart[numberButton] = {false, false, false, false};

LTexture backToMenuTexture[2];
SDL_Rect backToMenuRect[2];
bool fillBackToMenu[2] = {false, false};

LTexture pauseTexture;
LTexture backToGameTexuture;
SDL_Rect backToGameRect;
bool fillBackToGame = false;

LTexture guideTexture;
SDL_Rect guideRect;

LTexture mapTexture[3];
SDL_Rect mapRect[3];
bool renderBoarderMap[3];

LTexture loadingTexture, loadingFrame;
SDL_Rect loadingRect;

LTexture missionFailedTexture, missionPassedTexture;
LTexture blackGround;
bool reasonFailed[2];
LTexture reasonFailedTexture[2];
LTexture timePassedTexture;

void renderNumberBullet(int availableBullet, int bulletInStorage)
{
    SDL_Color textColor = { 0, 0, 0 };
    string ab = "Availble bullet: x " + to_string(availableBullet);
    string bis = "Bullet in storage: x " + to_string(bulletInStorage);
    abTexture.loadFromRenderedText(renderer, gFont, ab.c_str(), textColor);
    bisTexture.loadFromRenderedText(renderer, gFont, bis.c_str(), textColor);

    abTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 7 ) * BLOCK_SIDE - 10, 0);
    bisTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE - 10, BLOCK_SIDE );
}

void renderNumberOreTexture( Uint8 numberIron, Uint8 numberTitan, Uint8 numberSulfur)
{

    SDL_Color textColor = {0, 0, 0};
    string nText = "In storage: ";
    string nIron = to_string(numberIron);
    string nTitan = to_string(numberTitan);
    string nSulfur = to_string(numberSulfur);

    numberIronTexture.loadFromRenderedText(renderer, gFont, nIron.c_str(), textColor);
    numberTitanTexture.loadFromRenderedText(renderer, gFont, nTitan.c_str(), textColor);
    numberSulfurTexture.loadFromRenderedText(renderer, gFont, nSulfur.c_str(), textColor);


    lootIronTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE, BLOCK_SIDE * 2);
    numberIronTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 5) * BLOCK_SIDE, BLOCK_SIDE * 2);

    lootTitanTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE, BLOCK_SIDE * 3 + 12);
    numberTitanTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 5) * BLOCK_SIDE, BLOCK_SIDE * 3 + 12);

    lootSulfurTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE, BLOCK_SIDE * 4 + 24);
    numberSulfurTexture.render(renderer, (NUMBER_BLOCK_WIDTH - 5) * BLOCK_SIDE, BLOCK_SIDE * 4 + 24);


}

void renderGameTime()
{
    Uint32 seconds =  GAME_TIMER.getTicks() / 1000;
    Uint32 minutes =  seconds / 60;
    seconds = seconds - minutes * 60;
    string timeString = (minutes >= 10 ? "" : "0") + to_string (minutes) + ':' + (seconds >= 10 ? "" : "0") + to_string(seconds);
    timeTexture.loadFromRenderedText(renderer, gFont, timeString, SDL_Color{0, 0, 0});

    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
    SDL_RenderFillRect(renderer, &timeBG);

    clockTexture.render(renderer, timeBG.x + timeTexture.getWidth() / 2 - clockTexture.getWidth() / 2, timeBG.y);
    timeTexture.render(renderer, timeBG.x, timeBG.y + BLOCK_SIDE);

}

void renderKillsAndDeaths()
{
    SDL_Color textColor = {0, 0, 0};
    string killsAndDeaths = to_string(tank.getKills()) + "/" + to_string(tank.getDeaths());
    killsAndDeathsTexture.loadFromRenderedText(renderer, tFont, killsAndDeaths, textColor);

    killsAndDeathsBG.w = killsAndDeathsTexture.getWidth();
    SDL_SetRenderDrawColor(renderer, 255, 100, 100, 255);
    SDL_RenderFillRect(renderer, &killsAndDeathsBG);

    killsAndDeathsTexture.render(renderer, killsAndDeathsBG.x, killsAndDeathsBG.y);
}

void renderReloading()
{
    int reloadingX = tank.getPosX() - (reloadingTexture.getWidth() - 50) / 2 ;
    int reloadingY = tank.getPosY() - reloadingTexture.getHeight() - 30;
    SDL_Rect reloadingRect = {reloadingX, reloadingY, reloadingTexture.getWidth(), reloadingTexture.getHeight() };
    SDL_SetRenderDrawColor(renderer, 255,  255, 255, 0);
    SDL_RenderFillRect(renderer, &reloadingRect);
    reloadingTexture.render(renderer, reloadingX, reloadingY);

}

void renderNumberStoredOres(int numberIron, int numberTitan, int numberSulfur)
{
    SDL_Color textColor = {0, 0, 0};
    string nText = "Ores in storage: ";
    string nIron = to_string(numberIron);
    string nTitan = to_string(numberTitan);
    string nSulfur = to_string(numberSulfur);

    numberOreText.loadFromRenderedText (renderer, gFont, nText.c_str(), textColor);
    numOreTexture[0].loadFromRenderedText(renderer, gFont, nIron.c_str(), textColor);
    numOreTexture[1].loadFromRenderedText(renderer, gFont, nTitan.c_str(), textColor);
    numOreTexture[2].loadFromRenderedText(renderer, gFont, nSulfur.c_str(), textColor);

    numberOreText.render(renderer, tabPosX + BLOCK_SIDE, tabPosY + BLOCK_SIDE);

    oreShape[0].render(renderer,  tabPosX + BLOCK_SIDE, tabPosY + 2 * BLOCK_SIDE + 12);
    numOreTexture[0].render(renderer,  tabPosX + 2 * BLOCK_SIDE + 10, tabPosY + 2 * BLOCK_SIDE + 12);

    oreShape[1].render(renderer,  tabPosX + BLOCK_SIDE, tabPosY + 3 * BLOCK_SIDE + 24 );
    numOreTexture[1].render(renderer,  tabPosX + 2 * BLOCK_SIDE + 10, tabPosY + 3 *BLOCK_SIDE + 24);

    oreShape[2].render(renderer,  tabPosX + BLOCK_SIDE, tabPosY + 4 * BLOCK_SIDE + 36);
    numOreTexture[2].render(renderer,  tabPosX + 2 * BLOCK_SIDE + 10, tabPosY + 4 * BLOCK_SIDE + 36);


}

void renderLevels(Tank& tank)
{
    string levelStr[7];

    for (int i = 0; i < 7; i++)
    {
        levelStr[i] = to_string(tank.getLevel(i + 1));
    }

    SDL_Color textColor = {100, 0, 0};
    for (int i = 0; i < 7; i++)
    {
        levelTextures[i].loadFromRenderedText(renderer, gFont, levelStr[i].c_str(), textColor);
        levelTextures[i].render(renderer, tabPosX + 330 , tabPosY - 3 + BLOCK_SIDE * (7 + i));
    }

}

void renderUpgradeTable(Tank& tank)
{
    upgradeTable.render(renderer, uTableX, uTableY);
    boarder1.x = uTableX;
    boarder2.x = uTableX + 1;
    boarder1.y = uTableY + 36 * boarderIndex;
    boarder2.y = boarder1.y + 1;
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

    int nextLevel = tank.getLevel(boarderIndex) + 1;
    if (nextLevel <= 3)
    {
        materialTexture.render(renderer, uTableX, uTableY + upgradeTable.getHeight());
        numberMaterial[0] = UPGRADE_MATERIAL[boarderIndex][nextLevel].iron;
        numberMaterial[1] = UPGRADE_MATERIAL[boarderIndex][nextLevel].titan;
        numberMaterial[2] = UPGRADE_MATERIAL[boarderIndex][nextLevel].sulfur;

        bool isEnoughMaterial[3];
        for (Uint8 i = 0; i < 3; i++)
        {
            isEnoughMaterial[i] = false;
        }

        if (tank.getNumberStoredIron() >= numberMaterial[0]) isEnoughMaterial[0] = true;
        if (tank.getNumberStoredTitan() >= numberMaterial[1]) isEnoughMaterial[1] = true;
        if (tank.getNumberStoredSulfur() >= numberMaterial[2]) isEnoughMaterial[2] = true;


        SDL_Color color;

        for (int i = 0; i < 3; i++)
        {
            if (isEnoughMaterial[i])
            {
                color = SDL_Color {0, 215, 0};
            }
            else
            {
                color = SDL_Color {255, 0, 0};
            }
            numberMaterialTexture[i].loadFromRenderedText(renderer, gFont, to_string (numberMaterial[i]).c_str(), color);
            numberMaterialTexture[i].render(renderer, uTableX + 50 + 100 * i, uTableY + upgradeTable.getHeight() + 20);
        }

    }
    else
    {
        maxLevelTexture.render(renderer, uTableX, uTableY + upgradeTable.getHeight());
    }

    SDL_RenderDrawRect(renderer, &boarder2);
    SDL_RenderDrawRect(renderer, &boarder1);
}

void handleEventForMenu(SDL_Event &e)
{
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN  || e.type == SDL_KEYDOWN)
    {

        int mX, mY;
        SDL_GetMouseState(&mX, &mY);

        if (PAUSE)
        {
            for (int i = 0; i < numberButton; i++)
            {
                if ((mX > menuRects[i].x && mX < menuRects[i].x + menuRects[i].w) && ( mY > menuRects[i].y && mY < menuRects[i].y + menuRects[i].h))
                {
                    inMenuPart[i] = true;

                    if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
                    {
                        chooseMenuPart[i] = true;
                        Mix_PlayChannel(-1, buttonSound, 0);
                    }
                }
                else
                {
                    inMenuPart[i] = false;
                }

            }
        }
        else
        {
            for (int i = 1; i < numberButton; i++)
            {
                if ((mX > menuRects[i].x && mX < menuRects[i].x + menuRects[i].w) && ( mY > menuRects[i].y && mY < menuRects[i].y + menuRects[i].h))
                {
                    inMenuPart[i] = true;

                    if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
                    {
                        chooseMenuPart[i] = true;
                        Mix_PlayChannel(-1, buttonSound, 0);
                    }
                }
                else
                {
                    inMenuPart[i] = false;
                }

            }
        }

    }
}

void renderMenu()
{
    menuTexture.render(renderer, 0, 0);

    if (PAUSE)
    {
        for (int i = 0; i < numberButton; i++)
        {
            if (inMenuPart[i])
            {
                SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
                SDL_RenderFillRect(renderer, &menuRects[i]);
            }
            else
            {
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderFillRect(renderer, &menuRects[i]);
            }
            menuParts[i].render(renderer, menuRects[i].x, menuRects[i].y);
        }
    }
    else
    {
        for (int i = 1; i < numberButton; i++)
        {
            if (inMenuPart[i])
            {
                SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
                SDL_RenderFillRect(renderer, &menuRects[i]);
            }
            else
            {
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderFillRect(renderer, &menuRects[i]);
            }
            menuParts[i].render(renderer, menuRects[i].x, menuRects[i].y);
        }
    }

    if (chooseMenuPart[0])
    {
        GAME_STATUS = STARTED;
        chooseMenuPart[0] = false;
    }
    if (chooseMenuPart[1])
    {
        GAME_STATUS = LOADING;
        LOADING_FOR = CHOOSE_MAP;
        CHOOSE_ALLY = false;
        CHOOSE_TREATY = false;
        chooseMenuPart[1] = false;
    }
    if (chooseMenuPart[2])
    {
        GAME_STATUS = GUIDE;
        chooseMenuPart[2] = false;
    }
    if (chooseMenuPart[3])
    {
        GAME_STATUS = QUIT;
        chooseMenuPart[3] = false;
    }

}

float width = 0;
void renderLoading(float time)
{
    SDL_SetRenderDrawColor(renderer, 80, 200, 120, 255);
    SDL_RenderClear(renderer);
    width += (float) loadingTexture.getWidth() * time;
    loadingRect.w = width;
    loadingTexture.render(renderer, SCREEN_WIDTH / 2 - loadingTexture.getWidth() / 2, SCREEN_HEIGHT / 2 - loadingTexture.getHeight() / 2, &loadingRect);
    loadingFrame.render(renderer, SCREEN_WIDTH / 2 - loadingTexture.getWidth() / 2, SCREEN_HEIGHT / 2 - loadingTexture.getHeight() / 2);

    if ( loadingRect.w >= loadingTexture.getWidth())
    {
        GAME_STATUS = LOADING_FOR;
        loadingRect.w = 0;
        width = 0;
    }
}

void handleEventForChooseMap (SDL_Event &e)
{
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN  || e.type == SDL_KEYDOWN)
    {
        int mX, mY;
        SDL_GetMouseState(&mX, &mY);


        if ((mX > mapRect[MAP1].x && mX < mapRect[MAP1].x + mapRect[MAP1].w) && ( mY > mapRect[MAP1].y && mY < mapRect[MAP1].y + mapRect[MAP1].h) )
        {
            renderBoarderMap[MAP1] = true;
            renderBoarderMap[MAP2] = false;
            renderBoarderMap[MAP3] = false;
            fillBackToMenu[0] = false;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                GAME_MAP = MAP1;
                GAME_STATUS = LOADING;
                LOADING_FOR = CHOOSE_SIDE;
                loadMap1();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else if ((mX > mapRect[MAP2].x && mX < mapRect[MAP2].x + mapRect[MAP2].w) && ( mY > mapRect[MAP2].y && mY < mapRect[MAP2].y + mapRect[MAP2].h) )
        {
            renderBoarderMap[MAP1] = false;
            renderBoarderMap[MAP2] = true;
            renderBoarderMap[MAP3] = false;
            fillBackToMenu[0] = false;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                GAME_MAP = MAP2;
                GAME_STATUS = LOADING;
                LOADING_FOR = CHOOSE_SIDE;
                loadMap2();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else if ((mX > mapRect[MAP3].x && mX < mapRect[MAP3].x + mapRect[MAP3].w) && ( mY > mapRect[MAP3].y && mY < mapRect[MAP3].y + mapRect[MAP3].h) )
        {
            renderBoarderMap[MAP1] = false;
            renderBoarderMap[MAP2] = false;
            renderBoarderMap[MAP3] = true;
            fillBackToMenu[0] = false;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                GAME_MAP = MAP3;
                GAME_STATUS = LOADING;
                LOADING_FOR = CHOOSE_SIDE;
                loadMap3();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }

        else if ((mX > backToMenuRect[0].x && mX < backToMenuRect[0].x + backToMenuRect[0].w) && ( mY > backToMenuRect[0].y && mY < backToMenuRect[0].y + backToMenuRect[0].h) )
        {
            fillBackToMenu[0] = true;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                backToMenu();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else
        {
            fillBackToMenu[0] = false;
            renderBoarderMap[MAP1] = false;
            renderBoarderMap[MAP2] = false;
            renderBoarderMap[MAP3] = false;
        }

    }
}

void chooseMap()
{
    SDL_SetRenderDrawColor(renderer, 80, 200, 120, 255);
    SDL_RenderClear(renderer);

    for (Uint8 mapType = 0; mapType < 3; mapType++)
    {
        mapTexture[mapType].render(renderer, mapRect[mapType].x, mapRect[mapType].y);

        if (renderBoarderMap[mapType])
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_RenderDrawRect(renderer, mapRect + mapType);
        }
    }

    if (fillBackToMenu[0])
    {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(renderer, &backToMenuRect[0]);
    }
    else
    {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderFillRect(renderer, &backToMenuRect[0]);
    }

    backToMenuTexture[0].render(renderer, 20, 20);
}

void handleEventForchooseSide(SDL_Event &e)
{
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN  || e.type == SDL_KEYDOWN)
    {

        int mX, mY;
        SDL_GetMouseState(&mX, &mY);
        if ((mX > bgT.x && mX < bgT.x + bgT.w) && ( mY > bgT.y && mY < bgT.y + bgT.h) )
        {
            doRenderbgT = true;
            doRenderbgA = false;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                CHOOSE_TREATY = true;
                CHOOSE_ALLY = false;
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else if ((mX > bgA.x && mX < bgA.x + bgA.w) && ( mY > bgA.y && mY < bgA.y + bgA.h) )
        {
            doRenderbgA = true;
            doRenderbgT = false;

             if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                CHOOSE_ALLY = true;
                CHOOSE_TREATY = false;
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else
        {
            doRenderbgA = false;
            doRenderbgT = false;

        }
    }
}
void chooseSide()
{
    SDL_SetRenderDrawColor(renderer, 255, 242, 0, 255);
    SDL_RenderFillRect(renderer, &bg);

    if (doRenderbgA)
    {
        SDL_SetRenderDrawColor(renderer, 245, 228, 156, 255);
        SDL_RenderFillRect(renderer, &bgA);
    }

    if (doRenderbgT)
    {
        SDL_SetRenderDrawColor(renderer, 84, 109, 142, 255);
        SDL_RenderFillRect(renderer, &bgT);
    }

    chooseSideTexture.render(renderer, chooseSideX, chooseSideY);

    if (CHOOSE_ALLY)
    {
        tank.setPosition(spawnPointA.x, spawnPointA.y);
//        tank.setPosition(27 * BLOCK_SIDE, 6 * BLOCK_SIDE);
        tank.setTextures(AllyTankUp, AllyTankBot, AllyBrokenTankUp);
        tank.setRespawnPoint(spawnPointA);
        tank.chooseTurret(AllyTurret);
        tank.setStorageRect(storageA);
        tank.chooseToPlay(true);
        for (Uint8 i = 0; i < numberBotTank; i++)
        {
            botTank[i].setTextures(TreatyTankUp, TreatyTankBot, TreatyBrokenTankUp);
        }
        botTank[0].chooseTurret(TreatyTurret);

        botTank[numberBotTank - 1].AI_setOrbit(GuardOrbitsT);
        botTank[numberBotTank - 1].AI_setAlertRange(GuardWorkingRangesT);

        GAME_STATUS = STARTED;
        PAUSE = false;
        GAME_TIMER.start();
    }

    if (CHOOSE_TREATY)
    {
        tank.setPosition(spawnPointT.x, spawnPointT.y);
//        tank.setPosition(27 * BLOCK_SIDE, 6 * BLOCK_SIDE);
        tank.setTextures(TreatyTankUp, TreatyTankBot, TreatyBrokenTankUp);
        tank.setRespawnPoint(spawnPointT);
        tank.chooseTurret(TreatyTurret);
        tank.setStorageRect(storageT);
        tank.chooseToPlay(true);
        for (Uint8 i = 0; i < numberBotTank; i++)
        {
            botTank[i].setTextures(AllyTankUp, AllyTankBot, AllyBrokenTankUp);
        }
        botTank[0].chooseTurret(AllyTurret);

        botTank[numberBotTank - 1].AI_setOrbit(GuardOrbitsA);
        botTank[numberBotTank - 1].AI_setAlertRange(GuardWorkingRangesA);

        GAME_STATUS = STARTED;
        PAUSE = false;
        GAME_TIMER.start();
    }
}

void backToMenu()
{
    GAME_STATUS = IN_MENU;
}


void handleEventInGuide(SDL_Event &e)
{
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN  || e.type == SDL_KEYDOWN)
    {

        int mX, mY;
        SDL_GetMouseState(&mX, &mY);
        if ((mX > backToMenuRect[0].x && mX < backToMenuRect[0].x + backToMenuRect[0].w) && ( mY > backToMenuRect[0].y && mY < backToMenuRect[0].y + backToMenuRect[0].h) )
        {
            fillBackToMenu[0] = true;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                backToMenu();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else
        {
            fillBackToMenu[0] = false;
        }
    }
    else if (e.type == SDL_MOUSEWHEEL)
    {
        if (e.wheel.y > 0)
        {
            guideRect.y -= 60;
            if (guideRect.y < 0)
            {
                guideRect.y = 0;
            }
        }
        else if (e.wheel.y < 0)
        {
            guideRect.y += 60;
            if (guideRect.y + SCREEN_HEIGHT > guideTexture.getHeight())
            {
                guideRect.y = guideTexture.getHeight() - SCREEN_HEIGHT;
            }
        }
    }
}

void renderGuide()
{
    guideTexture.render(renderer, 0, 0, &guideRect);
    if (fillBackToMenu[0])
    {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(renderer, &backToMenuRect[0]);
    }
    else
    {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderFillRect(renderer, &backToMenuRect[0]);
    }

    backToMenuTexture[0].render(renderer, 20, 20);
}

void handleEvenWhenPaused(SDL_Event &e)
{
    if (e.type == SDL_MOUSEMOTION || e.type == SDL_MOUSEBUTTONDOWN  || e.type == SDL_KEYDOWN)
    {

        int mX, mY;
        SDL_GetMouseState(&mX, &mY);
        if ((mX > backToMenuRect[1].x && mX < backToMenuRect[1].x + backToMenuRect[1].w) && ( mY > backToMenuRect[1].y && mY < backToMenuRect[1].y + backToMenuRect[1].h) )
        {
            fillBackToMenu[1] = true;
            fillBackToGame = false;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                backToMenu();
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else if ((mX > backToGameRect.x && mX <backToGameRect.x + backToGameRect.w) && ( mY > backToGameRect.y && mY < backToGameRect.y + backToGameRect.h) )
        {
            fillBackToMenu[1] = false;
            fillBackToGame = true;
            if (e.button.button == SDL_BUTTON_LEFT || e.key.keysym.sym == SDLK_RETURN)
            {
                PAUSE = false;
                Mix_PlayChannel(-1, buttonSound, 0);
            }
        }
        else
        {
            fillBackToMenu[1] = false;
            fillBackToGame = false;
        }

    }
}

void renderPause()
{
    if (fillBackToMenu[1])
    {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 200);
        SDL_RenderFillRect(renderer, &backToMenuRect[1]);
    }
    else
    {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
        SDL_RenderFillRect(renderer, &backToMenuRect[1]);
    }

    if (fillBackToGame)
    {
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 200);
        SDL_RenderFillRect(renderer, &backToGameRect);
    }
    else
    {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
        SDL_RenderFillRect(renderer, &backToGameRect);
    }

    pauseTexture.render(renderer, SCREEN_WIDTH / 2 - pauseTexture.getWidth() / 2, SCREEN_HEIGHT / 2 - pauseTexture.getHeight() / 2);
    backToGameTexuture.render(renderer, backToGameRect.x, backToGameRect.y);
    backToMenuTexture[1].render(renderer, backToMenuRect[1].x, backToMenuRect[1].y);
}

float alpha = 100;
void renderMissionPassed()
{
    blackGround.setAlpha(alpha);
    blackGround.render(renderer, 0, 0);
    missionPassedTexture.render(renderer, (SCREEN_WIDTH - missionPassedTexture.getWidth()) / 2, (SCREEN_HEIGHT - missionPassedTexture.getHeight()) / 2);
    timePassedTexture.render(renderer, (SCREEN_WIDTH - timePassedTexture.getWidth()) / 2, 660);

    alpha+= 0.1;
    if (alpha >= 255)
    {
        GAME_STATUS = LOADING;
        LOADING_FOR = IN_MENU;
        alpha = 100;
    }
}

void renderMissionFailed()
{
    blackGround.setAlpha(alpha);
    blackGround.render(renderer, 0, 0);
    missionFailedTexture.render(renderer, (SCREEN_WIDTH - missionFailedTexture.getWidth()) / 2, (SCREEN_HEIGHT - missionFailedTexture.getHeight()) / 2 );

    if (reasonFailed[0])
    {
        reasonFailedTexture[0].render(renderer, (SCREEN_WIDTH - reasonFailedTexture[0].getWidth()) / 2, 660 );
    }
    else if (reasonFailed[1])
    {
        reasonFailedTexture[1].render(renderer, (SCREEN_WIDTH - reasonFailedTexture[1].getWidth()) / 2, 660 );
    }

    alpha+= 0.1;
    if (alpha >= 255)
    {
        GAME_STATUS = LOADING;
        LOADING_FOR = IN_MENU;
        alpha = 100;
    }
}


void setGameData()
{
    tank.setRenderer(renderer);
    tank.setFont(tFont);
    tank.setFumeTexture(fumeTexture);
    tank.setHPBarTexture(HPBarBlue, HPFrame, ArmorBar);
    tank.setBulletTexture(bullet);

    tank.setSounds(tank_shootSound, tank_takeDameSound, tank_armorSound, takeOreSound, buttonSound, upgradeSound, tank_runOutOfBulletSound, tank_reloadSound);

    for (int i = 0; i < 3; i++)
    {
        AllyTurret.push_back(Turret());
    }

    AllyTurret[0].setTexture(&AllyTurretTexture, &AllyTurretTexture);
    AllyTurret[1].setTexture(&ProtectiveTurretTexture, &ProtectiveTurretTexture_broken);
    AllyTurret[2].setTexture(&ProtectiveTurretTexture, &ProtectiveTurretTexture_broken);

    for (Uint8 i = 0; i < 3; i++)
    {
        AllyTurret[i].setHPBarTexture(ArmorBar, HPFrame);
    }

    for (Uint8 i = 0; i < 3; i++)
    {
        TreatyTurret.push_back(Turret());
    }

    TreatyTurret[0].setTexture(&TreatyMainTurretTexture, &TreatyMainTurretTexture);
    TreatyTurret[1].setTexture(&ProtectiveTurretTexture, &ProtectiveTurretTexture_broken);
    TreatyTurret[2].setTexture(&ProtectiveTurretTexture, &ProtectiveTurretTexture_broken);

    for (Uint8 i = 0; i < 3; i++)
    {
        TreatyTurret[i].setHPBarTexture(ArmorBar, HPFrame);
    }

    //set bot tanks
    for (Uint8 i = 0; i < numberBotTank; i++)
    {
        botTank.push_back(Tank());
    }

    GuardOrbitsA.push_back(SDL_Point{-100, -100});
    GuardWorkingRangesA.push_back(SDL_Rect {-100, -100, 0, 0});
    GuardWorkingRangesA.push_back(SDL_Rect {-100, -100, 0, 0});
    GuardWorkingRangesA.push_back(SDL_Rect {-100, -100, 0, 0});

    GuardOrbitsT.push_back(SDL_Point{-100, -100});
    GuardWorkingRangesT.push_back(SDL_Rect {-100, -100, 0, 0});
    GuardWorkingRangesA.push_back(SDL_Rect {-100, -100, 0, 0});
    GuardWorkingRangesA.push_back(SDL_Rect {-100, -100, 0, 0});

    for (Uint8 i = 0; i < numberBotTank; i++)
    {
        botTank[i].setRenderer(renderer);
        botTank[i].setFont(tFont);
        botTank[i].setDeadTime(30000);
        botTank[i].setBulletTexture(bullet);

        botTank[i].setHPBarTexture(HPBar, HPFrame, ArmorBar);

        botTank[i].setFumeTexture(fumeTexture);

        botTank[i].setSounds(bot_shootSound[i], bot_takeDameSound[i], bot_armorSound[i]);
    }

    botTank[0].setTurretSound (electricSound);

    //input map


    iron.setTexture(rawIronTexture, lootIronTexture);
    titan.setTexture(rawTitanTexture, lootTitanTexture);
    sulfur.setTexture(rawSulfurTexture, lootSulfurTexture);

    iron.setHP(6);
    titan.setHP(6);
    sulfur.setHP(5);

    iron.setSound(ore_takeDameSound, ore_brokenSound);
    titan.setSound(ore_takeDameSound, ore_brokenSound);
    sulfur.setSound(ore_takeDameSound, ore_brokenSound);

    tabTexture.setAlpha(200);

    pauseTexture.setAlpha(200);

    for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
    {
        for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
        {
            file_map1 >> BLOCK[MAP1][i][j].index;
            BLOCK[MAP1][i][j].block.x = j * BLOCK_SIDE;
            BLOCK[MAP1][i][j].block.y = i * BLOCK_SIDE;
            BLOCK[MAP1][i][j].block.w = BLOCK_SIDE;
            BLOCK[MAP1][i][j].block.h = BLOCK_SIDE;
            if (BLOCK[MAP1][i][j].index == 1 || BLOCK[MAP1][i][j].index == 3 || BLOCK[MAP1][i][j].index == 4 || BLOCK[MAP1][i][j].index == 5)
            {
                walls[MAP1].push_back(ArrayIndex(i, j));
            }

            else if (BLOCK[MAP1][i][j].index == 6)
            {
                ir[MAP1].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP1][i][j].index == 7)
            {
                t[MAP1].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP1][i][j].index == 8)
            {
                s[MAP1].push_back(ArrayIndex(j, i));
            }


            file_map2 >> BLOCK[MAP2][i][j].index;
            BLOCK[MAP2][i][j].block.x = j * BLOCK_SIDE;
            BLOCK[MAP2][i][j].block.y = i * BLOCK_SIDE;
            BLOCK[MAP2][i][j].block.w = BLOCK_SIDE;
            BLOCK[MAP2][i][j].block.h = BLOCK_SIDE;
            if (BLOCK[MAP2][i][j].index == 1 || BLOCK[MAP2][i][j].index == 3 || BLOCK[MAP2][i][j].index == 4 || BLOCK[MAP2][i][j].index == 5)
            {
                walls[MAP2].push_back(ArrayIndex(i, j));
            }

            else if (BLOCK[MAP2][i][j].index == 6)
            {
                ir[MAP2].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP2][i][j].index == 7)
            {
                t[MAP2].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP2][i][j].index == 8)
            {
                s[MAP2].push_back(ArrayIndex(j, i));
            }


            file_map3 >> BLOCK[MAP3][i][j].index;
            BLOCK[MAP3][i][j].block.x = j * BLOCK_SIDE;
            BLOCK[MAP3][i][j].block.y = i * BLOCK_SIDE;
            BLOCK[MAP3][i][j].block.w = BLOCK_SIDE;
            BLOCK[MAP3][i][j].block.h = BLOCK_SIDE;
            if (BLOCK[MAP3][i][j].index == 1 || BLOCK[MAP3][i][j].index == 3 || BLOCK[MAP3][i][j].index == 4 || BLOCK[MAP3][i][j].index == 5)
            {
                walls[MAP3].push_back(ArrayIndex(i, j));
            }

            else if (BLOCK[MAP3][i][j].index == 6)
            {
                ir[MAP3].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP3][i][j].index == 7)
            {
                t[MAP3].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP3][i][j].index == 8)
            {
                s[MAP3].push_back(ArrayIndex(j, i));
            }
            else if (BLOCK[MAP3][i][j].index == 9)
            {
                river[MAP3].push_back(ArrayIndex(i, j));
            }

        }
    }

}

void loadMap1()
{
    tank.reset();
    for (int i = 0; i < numberBotTank; i++)
    {
        botTank[i].AI_reset();
    }
    for (int i = 0; i < 3; i++)
    {
        AllyTurret[i].reset();
        TreatyTurret[i].reset();
    }

    iron.reset();
    titan.reset();
    sulfur.reset();

    tank.setTimeLineTexture(timeLine[MAP1]);

    FlagAllyX = BLOCK_SIDE;
    FlagAllyY = BLOCK_SIDE;

    FlagTreatyX = 50 * BLOCK_SIDE;
    FlagTreatyY = 26 * BLOCK_SIDE;


    turretAx0 = 5 * BLOCK_SIDE;
    turretAy0 = 5 * BLOCK_SIDE;
    turretAx1 = 1 * BLOCK_SIDE;
    turretAy1 = 12 * BLOCK_SIDE;
    turretAx2 = 14 * BLOCK_SIDE;
    turretAy2 = 5 * BLOCK_SIDE;

    turretTx0 = (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE;
    turretTy0 = (NUMBER_BLOCK_HEIGHT - 7) * BLOCK_SIDE;
    turretTx1 = 38 * BLOCK_SIDE;
    turretTy1 = 28 * BLOCK_SIDE;
    turretTx2 = 47 * BLOCK_SIDE;
    turretTy2 = 17 * BLOCK_SIDE;

    spawnPointA = { FlagAllyX + 29, FlagAllyY + 29 };
    spawnPointT = { FlagTreatyX + 29, FlagTreatyY + 29};
    storageA = {FlagAllyX, FlagAllyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    storageT = {FlagTreatyX, FlagTreatyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    AllyTurret[0].setPos(turretAx0, turretAy0);
    AllyTurret[0].setAttackRange(SDL_Rect {0, 0, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    AllyTurret[1].setPos(turretAx1, turretAy1);
    AllyTurret[1].setAttackRange(SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 9 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    AllyTurret[2].setPos(turretAx2, turretAy2);
    AllyTurret[2].setAttackRange(SDL_Rect {10 * BLOCK_SIDE, BLOCK_SIDE, 2 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[0].setPos(turretTx0, turretTy0);
    TreatyTurret[0].setAttackRange(SDL_Rect {44 * BLOCK_SIDE, 20 * BLOCK_SIDE, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[1].setPos(turretTx1, turretTy1);
    TreatyTurret[1].setAttackRange(SDL_Rect {38 * BLOCK_SIDE, 24 * BLOCK_SIDE, 6 * BLOCK_SIDE, 5 * BLOCK_SIDE});

    TreatyTurret[2].setPos(turretTx2, turretTy2);
    TreatyTurret[2].setAttackRange(SDL_Rect {42 * BLOCK_SIDE, 18 * BLOCK_SIDE, 11 * BLOCK_SIDE, 2 * BLOCK_SIDE});


    vector <SDL_Point> Orbits [numberBotTank];
    vector <SDL_Rect> WorkingRanges [numberBotTank];
    //set orbits
    Orbits[0].push_back(SDL_Point {17 * BLOCK_SIDE, 6 * BLOCK_SIDE});
    Orbits[0].push_back(SDL_Point {27 * BLOCK_SIDE, 6 * BLOCK_SIDE});

    Orbits[1].push_back (SDL_Point {20 * BLOCK_SIDE, 17 * BLOCK_SIDE});
    Orbits[1].push_back(SDL_Point {20 * BLOCK_SIDE, 24 * BLOCK_SIDE});

    Orbits[2].push_back(SDL_Point {30 * BLOCK_SIDE, 16 * BLOCK_SIDE});
    Orbits[2].push_back(SDL_Point {30 * BLOCK_SIDE, 24 * BLOCK_SIDE});

    Orbits[3].push_back (SDL_Point {36 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {47 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {47 * BLOCK_SIDE, 11 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {36 * BLOCK_SIDE, 11 * BLOCK_SIDE});

    Orbits[4].push_back (SDL_Point {33 * BLOCK_SIDE, 1 * BLOCK_SIDE});
    Orbits[4].push_back (SDL_Point {33 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    Orbits[5].push_back (SDL_Point {12 * BLOCK_SIDE, 16 * BLOCK_SIDE});
    Orbits[5].push_back (SDL_Point {9 * BLOCK_SIDE, 25 * BLOCK_SIDE});

    //set working ranges
    WorkingRanges[0].push_back(SDL_Rect {17 * BLOCK_SIDE, BLOCK_SIDE, 12 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect {17 * BLOCK_SIDE, 10 * BLOCK_SIDE, 8 * BLOCK_SIDE, 2 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect{14 * BLOCK_SIDE, 8 * BLOCK_SIDE, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect {26 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    WorkingRanges[1].push_back (SDL_Rect {15 * BLOCK_SIDE, 16 * BLOCK_SIDE, 12 * BLOCK_SIDE, 10 * BLOCK_SIDE});

    WorkingRanges[2].push_back (SDL_Rect {27 * BLOCK_SIDE, 14 * BLOCK_SIDE, 6 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    WorkingRanges[3].push_back (SDL_Rect {30 * BLOCK_SIDE, 9 * BLOCK_SIDE, 14 * BLOCK_SIDE, 4 * BLOCK_SIDE});
    WorkingRanges[3].push_back (SDL_Rect {43 * BLOCK_SIDE, 13 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    WorkingRanges[4].push_back (SDL_Rect { 30 * BLOCK_SIDE, 1 * BLOCK_SIDE, 7 * BLOCK_SIDE, 14 * BLOCK_SIDE});

    WorkingRanges[5].push_back (SDL_Rect { 9 * BLOCK_SIDE, 13 * BLOCK_SIDE, 7 * BLOCK_SIDE, 16 * BLOCK_SIDE});

    for (Uint8 i = 0; i < numberBotTank - 1; i++)
    {
        botTank[i].AI_setOrbit(Orbits[i]);
        botTank[i].AI_setAlertRange(WorkingRanges[i]);
        botTank[i].setTimeLineTexture(timeLine[MAP1]);
    }

    botTank[numberBotTank - 1].setTimeLineTexture(timeLine[MAP1]);

    GuardOrbitsA[0] = spawnPointA;
    GuardWorkingRangesA[0] = AllyTurret[0].getRange();
    GuardWorkingRangesA[0] = SDL_Rect {10 * BLOCK_SIDE, 1 * BLOCK_SIDE, 2 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    GuardWorkingRangesA[0] = SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE, 2 * BLOCK_SIDE};

    GuardOrbitsT[0] = spawnPointT;
    GuardWorkingRangesT[0] = TreatyTurret[0].getRange();
    GuardWorkingRangesT[0] = SDL_Rect {50 * BLOCK_SIDE, 18 * BLOCK_SIDE, 3 * BLOCK_SIDE, 2 * BLOCK_SIDE};
    GuardWorkingRangesT[0] = SDL_Rect {42 * BLOCK_SIDE, 26 * BLOCK_SIDE, 2 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
    {
        for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
        {
            GAME_BLOCK[i][j] = BLOCK[MAP1][i][j];
        }
    }
    GAME_walls = walls[MAP1];
    GAME_river = river[MAP1];

    iron.setRandomPos(ir[MAP1]);
    titan.setRandomPos(t[MAP1]);
    sulfur.setRandomPos(s[MAP1]);
}

void loadMap2()
{
    tank.reset();
    for (int i = 0; i < numberBotTank; i++)
    {
        botTank[i].AI_reset();
    }
    for (int i = 0; i < 3; i++)
    {
        AllyTurret[i].reset();
        TreatyTurret[i].reset();
    }

    iron.reset();
    titan.reset();
    sulfur.reset();

    tank.setTimeLineTexture(timeLine[MAP2]);

    FlagAllyX = BLOCK_SIDE;
    FlagAllyY = 14 * BLOCK_SIDE;

    FlagTreatyX = 50 * BLOCK_SIDE;
    FlagTreatyY = 14 * BLOCK_SIDE;


    turretAx0 = 5 * BLOCK_SIDE;
    turretAy0 = 15 * BLOCK_SIDE;
    turretAx1 = 5 * BLOCK_SIDE;
    turretAy1 = 20 * BLOCK_SIDE;
    turretAx2 = 5 * BLOCK_SIDE;
    turretAy2 = 11 * BLOCK_SIDE;

    turretTx0 = 47 * BLOCK_SIDE;
    turretTy0 = 14 * BLOCK_SIDE;
    turretTx1 = 47 * BLOCK_SIDE;
    turretTy1 = 19 * BLOCK_SIDE;
    turretTx2 = 47 * BLOCK_SIDE;
    turretTy2 = 10 * BLOCK_SIDE;

    spawnPointA = { FlagAllyX + 29, FlagAllyY + 29 };
    spawnPointT = { FlagTreatyX + 29, FlagTreatyY + 29};
    storageA = {FlagAllyX, FlagAllyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    storageT = {FlagTreatyX, FlagTreatyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    AllyTurret[0].setPos(turretAx0, turretAy0);
    AllyTurret[0].setAttackRange(SDL_Rect {BLOCK_SIDE, 12 * BLOCK_SIDE, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    AllyTurret[1].setPos(turretAx1, turretAy1);
    AllyTurret[1].setAttackRange(SDL_Rect {1 * BLOCK_SIDE, 20 * BLOCK_SIDE, 9 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    AllyTurret[2].setPos(turretAx2, turretAy2);
    AllyTurret[2].setAttackRange(SDL_Rect {1 * BLOCK_SIDE, 5 * BLOCK_SIDE, 9 * BLOCK_SIDE, 7 * BLOCK_SIDE});

    TreatyTurret[0].setPos(turretTx0, turretTy0);
    TreatyTurret[0].setAttackRange(SDL_Rect {44 * BLOCK_SIDE, 12 * BLOCK_SIDE, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[1].setPos(turretTx1, turretTy1);
    TreatyTurret[1].setAttackRange(SDL_Rect {44 * BLOCK_SIDE, 19 * BLOCK_SIDE, 9 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    TreatyTurret[2].setPos(turretTx2, turretTy2);
    TreatyTurret[2].setAttackRange(SDL_Rect {44 * BLOCK_SIDE, 7 * BLOCK_SIDE, 9 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    vector <SDL_Point> Orbits [numberBotTank];
    vector <SDL_Rect> WorkingRanges [numberBotTank];
    //set orbits
    Orbits[0].push_back(SDL_Point {25 * BLOCK_SIDE, 4 * BLOCK_SIDE});
    Orbits[0].push_back(SDL_Point {25 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    Orbits[1].push_back (SDL_Point {5 * BLOCK_SIDE, 1 * BLOCK_SIDE});
    Orbits[1].push_back(SDL_Point {20 * BLOCK_SIDE, 1 * BLOCK_SIDE});

    Orbits[2].push_back(SDL_Point {39 * BLOCK_SIDE, 4 * BLOCK_SIDE});
    Orbits[2].push_back(SDL_Point {26 * BLOCK_SIDE, 18 * BLOCK_SIDE});

    Orbits[3].push_back (SDL_Point {7 * BLOCK_SIDE, 27 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {18 * BLOCK_SIDE, 27 * BLOCK_SIDE});

    Orbits[4].push_back (SDL_Point {40 * BLOCK_SIDE, 20 * BLOCK_SIDE});
    Orbits[4].push_back (SDL_Point {40 * BLOCK_SIDE, 27 * BLOCK_SIDE});
    Orbits[4].push_back (SDL_Point {49 * BLOCK_SIDE, 27 * BLOCK_SIDE});


    Orbits[5].push_back (SDL_Point {15 * BLOCK_SIDE, 14 * BLOCK_SIDE});
    Orbits[5].push_back (SDL_Point {22 * BLOCK_SIDE, 16 * BLOCK_SIDE});

    //set working ranges
    WorkingRanges[0].push_back(SDL_Rect {20 * BLOCK_SIDE, 6 * BLOCK_SIDE, 11 * BLOCK_SIDE, 5 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect {22 * BLOCK_SIDE, 3 * BLOCK_SIDE, 7 * BLOCK_SIDE, 2 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect{22 * BLOCK_SIDE, 12 * BLOCK_SIDE, 7 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    WorkingRanges[1].push_back (SDL_Rect {1 * BLOCK_SIDE, 1 * BLOCK_SIDE, 20 * BLOCK_SIDE, 3 * BLOCK_SIDE});
    WorkingRanges[1].push_back (SDL_Rect {7 * BLOCK_SIDE, 4 * BLOCK_SIDE, 14 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    WorkingRanges[2].push_back (SDL_Rect {33 * BLOCK_SIDE, 3 * BLOCK_SIDE, 8 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    WorkingRanges[2].push_back (SDL_Rect {31 * BLOCK_SIDE, 11 * BLOCK_SIDE, 2 * BLOCK_SIDE, 6 * BLOCK_SIDE});
    WorkingRanges[2].push_back (SDL_Rect {28 * BLOCK_SIDE, 14 * BLOCK_SIDE, 2 * BLOCK_SIDE, 6 * BLOCK_SIDE});
    WorkingRanges[2].push_back (SDL_Rect {25 * BLOCK_SIDE, 17 * BLOCK_SIDE, 2 * BLOCK_SIDE, 6 * BLOCK_SIDE});
    WorkingRanges[2].push_back (SDL_Rect {22 * BLOCK_SIDE, 19 * BLOCK_SIDE, 2 * BLOCK_SIDE, 6 * BLOCK_SIDE});

    WorkingRanges[3].push_back (SDL_Rect {1 * BLOCK_SIDE, 26 * BLOCK_SIDE, 21 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    WorkingRanges[4].push_back (SDL_Rect { 37 * BLOCK_SIDE, 26 * BLOCK_SIDE, 16 * BLOCK_SIDE, 3 * BLOCK_SIDE});
    WorkingRanges[4].push_back (SDL_Rect { 40 * BLOCK_SIDE, 18 * BLOCK_SIDE, 5 * BLOCK_SIDE, 8 * BLOCK_SIDE});

    WorkingRanges[5].push_back (SDL_Rect { 14 * BLOCK_SIDE, 10 * BLOCK_SIDE, 4 * BLOCK_SIDE, 8 * BLOCK_SIDE});
    WorkingRanges[5].push_back (SDL_Rect { 19 * BLOCK_SIDE, 12 * BLOCK_SIDE, 2 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    WorkingRanges[5].push_back (SDL_Rect { 22 * BLOCK_SIDE, 14 * BLOCK_SIDE, 2 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    for (Uint8 i = 0; i < numberBotTank - 1; i++)
    {
        botTank[i].AI_setOrbit(Orbits[i]);
        botTank[i].AI_setAlertRange(WorkingRanges[i]);
        botTank[i].setTimeLineTexture(timeLine[MAP2]);
    }

    botTank[numberBotTank - 1].setTimeLineTexture(timeLine[MAP2]);

    GuardOrbitsA[0] = spawnPointA;
    GuardWorkingRangesA[0] = AllyTurret[0].getRange();
    GuardWorkingRangesA[0] = SDL_Rect {1 * BLOCK_SIDE, 5 * BLOCK_SIDE, 3 * BLOCK_SIDE, 7 * BLOCK_SIDE};
    GuardWorkingRangesA[0] = SDL_Rect {1 * BLOCK_SIDE, 20 * BLOCK_SIDE, 3 * BLOCK_SIDE, 5 * BLOCK_SIDE};

    GuardOrbitsT[0] = spawnPointT;
    GuardWorkingRangesT[0] = TreatyTurret[0].getRange();
    GuardWorkingRangesT[0] = SDL_Rect {50 * BLOCK_SIDE, 7 * BLOCK_SIDE, 3 * BLOCK_SIDE, 4 * BLOCK_SIDE};
    GuardWorkingRangesT[0] = SDL_Rect {50 * BLOCK_SIDE, 19 * BLOCK_SIDE, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
    {
        for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
        {
            GAME_BLOCK[i][j] = BLOCK[MAP2][i][j];
        }
    }
    GAME_walls = walls[MAP2];
    GAME_river = river[MAP2];

    iron.setRandomPos(ir[MAP2]);
    titan.setRandomPos(t[MAP2]);
    sulfur.setRandomPos(s[MAP2]);
}

void loadMap3()
{
    tank.reset();
    for (int i = 0; i < numberBotTank; i++)
    {
        botTank[i].AI_reset();
    }
    for (int i = 0; i < 3; i++)
    {
        AllyTurret[i].reset();
        TreatyTurret[i].reset();
    }

    iron.reset();
    titan.reset();
    sulfur.reset();

    tank.setTimeLineTexture(timeLine[MAP3]);

    FlagAllyX = BLOCK_SIDE;
    FlagAllyY = BLOCK_SIDE;

    FlagTreatyX = 42 * BLOCK_SIDE;
    FlagTreatyY = 1 * BLOCK_SIDE;


    turretAx0 = 5 * BLOCK_SIDE;
    turretAy0 = 5 * BLOCK_SIDE;
    turretAx1 = 1 * BLOCK_SIDE;
    turretAy1 = 12 * BLOCK_SIDE;
    turretAx2 = 13 * BLOCK_SIDE;
    turretAy2 = 1 * BLOCK_SIDE;

    turretTx0 = 39 * BLOCK_SIDE;
    turretTy0 = 5 * BLOCK_SIDE;
    turretTx1 = 39 * BLOCK_SIDE;
    turretTy1 = 13 * BLOCK_SIDE;
    turretTx2 = 32 * BLOCK_SIDE;
    turretTy2 = 1 * BLOCK_SIDE;

    spawnPointA = { FlagAllyX + 29, FlagAllyY + 29 };
    spawnPointT = { FlagTreatyX + 29, FlagTreatyY + 29};
    storageA = {FlagAllyX, FlagAllyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    storageT = {FlagTreatyX, FlagTreatyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    AllyTurret[0].setPos(turretAx0, turretAy0);
    AllyTurret[0].setAttackRange(SDL_Rect {BLOCK_SIDE, BLOCK_SIDE, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    AllyTurret[1].setPos(turretAx1, turretAy1);
    AllyTurret[1].setAttackRange(SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 9 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    AllyTurret[2].setPos(turretAx2, turretAy2);
    AllyTurret[2].setAttackRange(SDL_Rect {10 * BLOCK_SIDE, 1 * BLOCK_SIDE, 3 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[0].setPos(turretTx0, turretTy0);
    TreatyTurret[0].setAttackRange(SDL_Rect {36 * BLOCK_SIDE, 1 * BLOCK_SIDE, 13 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[1].setPos(turretTx1, turretTy1);
    TreatyTurret[1].setAttackRange(SDL_Rect {36 * BLOCK_SIDE, 10 * BLOCK_SIDE, 11 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    TreatyTurret[2].setPos(turretTx2, turretTy2);
    TreatyTurret[2].setAttackRange(SDL_Rect {32 * BLOCK_SIDE, 1 * BLOCK_SIDE, 4 * BLOCK_SIDE, 6 * BLOCK_SIDE});


    vector <SDL_Point> Orbits [numberBotTank];
    vector <SDL_Rect> WorkingRanges [numberBotTank];
    //set orbits
    Orbits[0].push_back(SDL_Point {18 * BLOCK_SIDE, 16 * BLOCK_SIDE});
    Orbits[0].push_back(SDL_Point {32 * BLOCK_SIDE, 16 * BLOCK_SIDE});

    Orbits[1].push_back (SDL_Point {14 * BLOCK_SIDE, 3 * BLOCK_SIDE});
    Orbits[1].push_back(SDL_Point {20 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    Orbits[2].push_back(SDL_Point {33 * BLOCK_SIDE, 27 * BLOCK_SIDE});
    Orbits[2].push_back(SDL_Point {52 * BLOCK_SIDE, 27 * BLOCK_SIDE});

    Orbits[3].push_back (SDL_Point {13 * BLOCK_SIDE, 27 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {26 * BLOCK_SIDE, 27 * BLOCK_SIDE});

    Orbits[4].push_back (SDL_Point {39 * BLOCK_SIDE, 15 * BLOCK_SIDE});
    Orbits[4].push_back (SDL_Point {39 * BLOCK_SIDE, 24 * BLOCK_SIDE});

    Orbits[5].push_back (SDL_Point {23 * BLOCK_SIDE + 14, 11 * BLOCK_SIDE + 14});

    //set working ranges
    WorkingRanges[0].push_back(SDL_Rect {10 * BLOCK_SIDE, 16 * BLOCK_SIDE, 24 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    WorkingRanges[1].push_back (SDL_Rect {15 * BLOCK_SIDE, 1 * BLOCK_SIDE, 11 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    WorkingRanges[2].push_back (SDL_Rect {32 * BLOCK_SIDE, 27 * BLOCK_SIDE, 21 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    WorkingRanges[3].push_back (SDL_Rect {13 * BLOCK_SIDE, 27 * BLOCK_SIDE, 15 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    WorkingRanges[4].push_back (SDL_Rect { 38 * BLOCK_SIDE, 15 * BLOCK_SIDE, 4 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    WorkingRanges[5].push_back (SDL_Rect { 22 * BLOCK_SIDE, 1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 11 * BLOCK_SIDE});
    WorkingRanges[5].push_back (SDL_Rect { 15 * BLOCK_SIDE, 9 * BLOCK_SIDE, 7 * BLOCK_SIDE, 4 * BLOCK_SIDE});
    WorkingRanges[5].push_back (SDL_Rect { 23 * BLOCK_SIDE, 13 * BLOCK_SIDE, 2 * BLOCK_SIDE, 2 * BLOCK_SIDE});

    for (Uint8 i = 0; i < numberBotTank - 1; i++)
    {
        botTank[i].AI_setOrbit(Orbits[i]);
        botTank[i].AI_setAlertRange(WorkingRanges[i]);
        botTank[i].setTimeLineTexture(timeLine[MAP3]);
    }

    botTank[numberBotTank - 1].setTimeLineTexture(timeLine[MAP3]);

    GuardOrbitsA[0] = spawnPointA;
    GuardWorkingRangesA[0] = AllyTurret[0].getRange();
    GuardWorkingRangesA[0] = SDL_Rect {10 * BLOCK_SIDE, 1 * BLOCK_SIDE, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    GuardWorkingRangesA[0] = SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE, 2 * BLOCK_SIDE};

    GuardOrbitsT[0] = spawnPointT;
    GuardWorkingRangesT[0] = TreatyTurret[0].getRange();
    GuardWorkingRangesT[0] = SDL_Rect {34 * BLOCK_SIDE, 1 * BLOCK_SIDE, 4 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    GuardWorkingRangesT[0] = SDL_Rect {43 * BLOCK_SIDE, 10 * BLOCK_SIDE, 4 * BLOCK_SIDE, 6 * BLOCK_SIDE};

    for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
    {
        for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
        {
            GAME_BLOCK[i][j] = BLOCK[MAP3][i][j];
        }
    }
    GAME_walls = walls[MAP3];
    GAME_river = river[MAP3];

    iron.setRandomPos(ir[MAP3]);
    titan.setRandomPos(t[MAP3]);
    sulfur.setRandomPos(s[MAP3]);
}

void loadTestMap()
{
    tank.reset();
    for (int i = 0; i < numberBotTank; i++)
    {
        botTank[i].AI_reset();
    }
    for (int i = 0; i < 3; i++)
    {
        AllyTurret[i].reset();
        TreatyTurret[i].reset();
    }

    iron.reset();
    titan.reset();
    sulfur.reset();

    tank.setTimeLineTexture(timeLine[MAP1]);

    FlagAllyX = BLOCK_SIDE;
    FlagAllyY = BLOCK_SIDE;

    FlagTreatyX = 50 * BLOCK_SIDE;
    FlagTreatyY = 26 * BLOCK_SIDE;


    turretAx0 = 5 * BLOCK_SIDE;
    turretAy0 = 5 * BLOCK_SIDE;
    turretAx1 = 1 * BLOCK_SIDE;
    turretAy1 = 12 * BLOCK_SIDE;
    turretAx2 = 14 * BLOCK_SIDE;
    turretAy2 = 5 * BLOCK_SIDE;

    turretTx0 = (NUMBER_BLOCK_WIDTH - 7) * BLOCK_SIDE;
    turretTy0 = (NUMBER_BLOCK_HEIGHT - 7) * BLOCK_SIDE;
    turretTx1 = 38 * BLOCK_SIDE;
    turretTy1 = 28 * BLOCK_SIDE;
    turretTx2 = 47 * BLOCK_SIDE;
    turretTy2 = 17 * BLOCK_SIDE;

    spawnPointA = { FlagAllyX + 29, FlagAllyY + 29 };
    spawnPointT = { FlagTreatyX + 29, FlagTreatyY + 29};
    storageA = {FlagAllyX, FlagAllyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    storageT = {FlagTreatyX, FlagTreatyY, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    AllyTurret[0].setPos(turretAx0, turretAy0);
    AllyTurret[0].setAttackRange(SDL_Rect {0, 0, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    AllyTurret[1].setPos(turretAx1, turretAy1);
    AllyTurret[1].setAttackRange(SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 9 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    AllyTurret[2].setPos(turretAx2, turretAy2);
    AllyTurret[2].setAttackRange(SDL_Rect {10 * BLOCK_SIDE, BLOCK_SIDE, 2 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[0].setPos(turretTx0, turretTy0);
    TreatyTurret[0].setAttackRange(SDL_Rect {44 * BLOCK_SIDE, 20 * BLOCK_SIDE, 9 * BLOCK_SIDE, 9 * BLOCK_SIDE});

    TreatyTurret[1].setPos(turretTx1, turretTy1);
    TreatyTurret[1].setAttackRange(SDL_Rect {38 * BLOCK_SIDE, 24 * BLOCK_SIDE, 6 * BLOCK_SIDE, 5 * BLOCK_SIDE});

    TreatyTurret[2].setPos(turretTx2, turretTy2);
    TreatyTurret[2].setAttackRange(SDL_Rect {42 * BLOCK_SIDE, 18 * BLOCK_SIDE, 11 * BLOCK_SIDE, 2 * BLOCK_SIDE});


    vector <SDL_Point> Orbits [numberBotTank];
    vector <SDL_Rect> WorkingRanges [numberBotTank];
    //set orbits
    Orbits[0].push_back(SDL_Point {17 * BLOCK_SIDE, 6 * BLOCK_SIDE});
    Orbits[0].push_back(SDL_Point {27 * BLOCK_SIDE, 6 * BLOCK_SIDE});

    Orbits[1].push_back (SDL_Point {20 * BLOCK_SIDE, 17 * BLOCK_SIDE});
    Orbits[1].push_back(SDL_Point {20 * BLOCK_SIDE, 24 * BLOCK_SIDE});

    Orbits[2].push_back(SDL_Point {30 * BLOCK_SIDE, 16 * BLOCK_SIDE});
    Orbits[2].push_back(SDL_Point {30 * BLOCK_SIDE, 24 * BLOCK_SIDE});

    Orbits[3].push_back (SDL_Point {36 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {47 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {47 * BLOCK_SIDE, 11 * BLOCK_SIDE});
    Orbits[3].push_back (SDL_Point {36 * BLOCK_SIDE, 11 * BLOCK_SIDE});

    Orbits[4].push_back (SDL_Point {33 * BLOCK_SIDE, 1 * BLOCK_SIDE});
    Orbits[4].push_back (SDL_Point {33 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    Orbits[5].push_back (SDL_Point {12 * BLOCK_SIDE, 16 * BLOCK_SIDE});
    Orbits[5].push_back (SDL_Point {9 * BLOCK_SIDE, 25 * BLOCK_SIDE});

    //set working ranges
    WorkingRanges[0].push_back(SDL_Rect {17 * BLOCK_SIDE, BLOCK_SIDE, 12 * BLOCK_SIDE, 9 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect {17 * BLOCK_SIDE, 10 * BLOCK_SIDE, 8 * BLOCK_SIDE, 2 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect{14 * BLOCK_SIDE, 8 * BLOCK_SIDE, 3 * BLOCK_SIDE, 3 * BLOCK_SIDE});
    WorkingRanges[0].push_back(SDL_Rect {26 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE, 4 * BLOCK_SIDE});

    WorkingRanges[1].push_back (SDL_Rect {15 * BLOCK_SIDE, 16 * BLOCK_SIDE, 12 * BLOCK_SIDE, 10 * BLOCK_SIDE});

    WorkingRanges[2].push_back (SDL_Rect {27 * BLOCK_SIDE, 14 * BLOCK_SIDE, 6 * BLOCK_SIDE, 12 * BLOCK_SIDE});

    WorkingRanges[3].push_back (SDL_Rect {30 * BLOCK_SIDE, 9 * BLOCK_SIDE, 14 * BLOCK_SIDE, 4 * BLOCK_SIDE});
    WorkingRanges[3].push_back (SDL_Rect {43 * BLOCK_SIDE, 13 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE});

    WorkingRanges[4].push_back (SDL_Rect { 30 * BLOCK_SIDE, 1 * BLOCK_SIDE, 7 * BLOCK_SIDE, 14 * BLOCK_SIDE});

    WorkingRanges[5].push_back (SDL_Rect { 9 * BLOCK_SIDE, 13 * BLOCK_SIDE, 7 * BLOCK_SIDE, 16 * BLOCK_SIDE});

    for (Uint8 i = 0; i < numberBotTank - 1; i++)
    {
        botTank[i].AI_setOrbit(Orbits[i]);
        botTank[i].AI_setAlertRange(WorkingRanges[i]);
        botTank[i].setTimeLineTexture(timeLine[MAP1]);
    }

    botTank[numberBotTank - 1].setTimeLineTexture(timeLine[MAP1]);

    GuardOrbitsA[0] = spawnPointA;
    GuardWorkingRangesA[0] = AllyTurret[0].getRange();
    GuardWorkingRangesA[0] = SDL_Rect {10 * BLOCK_SIDE, 1 * BLOCK_SIDE, 2 * BLOCK_SIDE, 3 * BLOCK_SIDE};
    GuardWorkingRangesA[0] = SDL_Rect {1 * BLOCK_SIDE, 10 * BLOCK_SIDE, 3 * BLOCK_SIDE, 2 * BLOCK_SIDE};

    GuardOrbitsT[0] = spawnPointT;
    GuardWorkingRangesT[0] = TreatyTurret[0].getRange();
    GuardWorkingRangesT[0] = SDL_Rect {50 * BLOCK_SIDE, 18 * BLOCK_SIDE, 3 * BLOCK_SIDE, 2 * BLOCK_SIDE};
    GuardWorkingRangesT[0] = SDL_Rect {42 * BLOCK_SIDE, 26 * BLOCK_SIDE, 2 * BLOCK_SIDE, 3 * BLOCK_SIDE};

    for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
    {
        for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
        {
            GAME_BLOCK[i][j] = BLOCK[MAP1][i][j];
        }
    }
    GAME_walls = walls[MAP1];
    GAME_river = river[MAP1];

    iron.setRandomPos(ir[MAP1]);
    titan.setRandomPos(t[MAP1]);
    sulfur.setRandomPos(s[MAP1]);
}


//////////////////////////////////
bool init()
{
    bool success = true;

    if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
        cout << "SDL could not initialize! " << SDL_GetError() << endl;
        success = false;
    }
    else
    {
        window = SDL_CreateWindow(WINDOW_TITLE.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);

        if (window == NULL)
        {
            cout << "Could not create window " << SDL_GetError() << endl;
            success = false;
        }
        else
        {
            renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
            //tab_renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

            if (renderer == NULL )
            {
                cout << "Could not create renderer " << SDL_GetError() << endl;
                success = false;
            }
            else
            {
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

                int imFlags = IMG_INIT_PNG;
                if (!(IMG_Init(imFlags) & imFlags))
                {
                    cout << "SDL_image could not initialize " << IMG_GetError();
                    success = false;
                }

                if (TTF_Init() == -1)
                {
                    printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
                    success = false;
                }

                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
				{
					printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
					success = false;
				}
            }
        }
    }

    return success;
}

void close()
{
    SDL_DestroyRenderer(renderer);
    renderer = NULL;

    SDL_DestroyWindow(window);
    window = NULL;

    gFont = NULL;

    SDL_Quit();
    IMG_Quit();
    TTF_Quit();
}

string AllyTankUpPath[4] =
{
    "DrawingGame\\upL_0.png",
    "DrawingGame\\upL_1.png",
    "DrawingGame\\upL_2.png",
    "DrawingGame\\upL_3.png"
};
string AllyBrokenTankUpPath[4] =
{
    "DrawingGame\\brokenL_0.png",
    "DrawingGame\\brokenL_1.png",
    "DrawingGame\\brokenL_2.png",
    "DrawingGame\\brokenL_3.png"
};
string TreatyTankUpPath[4] =
{
    "DrawingGame\\upT_0.png",
    "DrawingGame\\upT_1.png",
    "DrawingGame\\upT_2.png",
    "DrawingGame\\upT_3.png"
};
string TreatyBrokenTankUpPath[4] =
{
    "DrawingGame\\brokenT_0.png",
    "DrawingGame\\brokenT_1.png",
    "DrawingGame\\brokenT_2.png",
    "DrawingGame\\brokenT_3.png"
};

string allBlockPath[10]
{
    "DrawingGame\\map1_block0.png",
    "DrawingGame\\map1_block1.png",
    "DrawingGame\\map1_block5.png",

    "DrawingGame\\map2_block0.png",
    "DrawingGame\\map2_block1.png",
    "DrawingGame\\map2_block5.png",

    "DrawingGame\\map3_block0.png",
    "DrawingGame\\map3_block1.png",
    "DrawingGame\\map3_block5.png",
    "DrawingGame\\map3_block9.png"
};

string bulletPath[4] =
{
    "DrawingGame\\bullet_0.png",
    "DrawingGame\\bullet_1.png",
    "DrawingGame\\bullet_2.png",
    "DrawingGame\\bullet_3.png"
};

string fumePath[5] =
{
    "DrawingGame\\fume0.png",
    "DrawingGame\\fume1.png",
    "DrawingGame\\fume2.png",
    "DrawingGame\\fume3.png",
    "DrawingGame\\fume4.png"

};

string menuPaths[numberButton]
{
    "DrawingGame\\menu_continue.png",
    "DrawingGame\\menu_new game.png",
    "DrawingGame\\menu_guide.png",
    "DrawingGame\\menu_quit.png",

};

string mapTexturePath [3]
{
    "DrawingGame\\map1.png",
    "DrawingGame\\map2.png",
    "DrawingGame\\map3.png"
};

string timeLinePath[3]
{
    "DrawingGame\\time line 1.png",
    "DrawingGame\\time line 2.png",
    "DrawingGame\\time line 3.png"
};

bool loadMediaTank()
{
    bool success = true;

    for (int i = 0; i < 4; i++)
    {
        if (!AllyTankUp[i].loadFromFile(renderer, AllyTankUpPath[i]) || !TreatyTankUp[i].loadFromFile(renderer, TreatyTankUpPath[i]))
        {
            cout << " Failed to load tankups " << endl;
            success = false;
        }
        if (!AllyBrokenTankUp[i].loadFromFile(renderer, AllyBrokenTankUpPath[i]) || !TreatyBrokenTankUp[i].loadFromFile(renderer, TreatyBrokenTankUpPath[i]))
        {
            cout << " Failed to load broken tankups" << endl;
            success = false;
        }
        if (!bullet[i].loadFromFile(renderer, bulletPath[i]))
        {
            cout << " Failed to load bullet texture" << endl;
            success = false;
        }
    }
    if (!AllyTankBot.loadFromFile(renderer, "DrawingGame\\bottomL.png") || !TreatyTankBot.loadFromFile(renderer, "DrawingGame\\bottomT.png"))

    {
        cout << " Failed to load bottom tank texture " << endl;
        success = false;
    }

    for (int i = 0; i < 5; i++)
    {

        if (!fumeTexture[i].loadFromFile(renderer, fumePath[i]))
        {
            cout << " Failed to load fume texture" << endl;
            success = false;
        }

    }

    for (int i = 0; i < 3; i++)
    {
        if(!block[MAP1][i].loadFromFile(renderer, allBlockPath[i]))
        {
            cout << " Failed to load block for map 1 " << endl;
            success = false;
        }

        if (!block[MAP2][i].loadFromFile(renderer, allBlockPath[i + 3]))
        {
            cout << " Failed to load block for map 2 " << endl;
            success = false;
        }

        if (!block[MAP3][i].loadFromFile(renderer, allBlockPath[i + 6]))
        {
            cout << " Failed to load block for map 3 " << SDL_GetError() <<  endl;
            success = false;
        }
    }

    if (!block[MAP3][3].loadFromFile(renderer, allBlockPath[9]))
    {
        cout << " Failed to load block 9 " << endl;
        success = false;
    }

    if (!AllyFlag.loadFromFile(renderer, "DrawingGame\\flagAlly.png") || !TreatyFlag.loadFromFile(renderer, "DrawingGame\\flagTreaty.png"))
    {
        cout << " Failed to load flag " << endl;
        success = false;
    }

    if (!AllyTurretTexture.loadFromFile(renderer, "DrawingGame\\turretL.png") || !TreatyMainTurretTexture.loadFromFile(renderer, "DrawingGame\\turretT.png"))
    {
        cout << " Failed to load turret texture" << endl;
        success = false;
    }

    if (!ProtectiveTurretTexture.loadFromFile(renderer, "DrawingGame\\protectTurret.png") || !ProtectiveTurretTexture_broken.loadFromFile(renderer, "DrawingGame\\protectTurretBroken.png"))
    {
        cout << " Failed to load protect turret texture " << endl;
        success = false;
    }

    if (!rawIronTexture.loadFromFile(renderer, "DrawingGame\\r iron.png") || !rawTitanTexture.loadFromFile(renderer, "DrawingGame\\r titan.png") ||
        !rawSulfurTexture.loadFromFile(renderer, "DrawingGame\\r sulfur.png"))
    {
        cout << " Failed to load raw ore textures " << endl;
        success = false;
    }

    if (!lootIronTexture.loadFromFile(renderer, "DrawingGame\\b iron.png") || !lootTitanTexture.loadFromFile(renderer, "DrawingGame\\b titan.png") ||
        !lootSulfurTexture.loadFromFile(renderer, "DrawingGame\\b sulfur.png"))
    {
        cout << " Failed to load loot ore textures" << endl;
        success = false;
    }
    else
    {
        oreShape[0] = lootIronTexture;
        oreShape[1] = lootTitanTexture;
        oreShape[2] = lootSulfurTexture;
    }

    if (!HPFrame.loadFromFile(renderer, "DrawingGame\\bloodFrame small.png") || !HPBar.loadFromFile(renderer, "DrawingGame\\blood small.png")
        || !ArmorBar.loadFromFile(renderer, "DrawingGame\\armor small.png") || !HPBarBlue.loadFromFile(renderer, "DrawingGame\\blood small blue.png"))
    {
        cout << " Failed to load HP textures " << endl;
        success = false;
    }

    if (!tabTexture.loadFromFile(renderer, "DrawingGame\\tabTexture.png"))
    {
        cout << " Failed to load tab texture" << endl;
        success = false;
    }

    if (!upgradeTable.loadFromFile(renderer, "DrawingGame\\upgradeTable.png"))
    {
        cout << " Failed to load upgrade table texture " <<endl;
        success = false;
    }
    if(!materialTexture.loadFromFile(renderer, "DrawingGame\\material.png"))
    {
        cout << " Failed to load material texture" << endl;
        success = false;
    }
    if (!maxLevelTexture.loadFromFile(renderer, "DrawingGame\\MAXLEVEL.png"))
    {
        cout << " Failed to load max level texture" << endl;
        success = false;
    }
    if (!chooseSideTexture.loadFromFile(renderer, "DrawingGame\\chooseSide.png"))
    {
        cout << " Failed to load choose side texture" << endl;
        success = false;
    }
    if (!clockTexture.loadFromFile(renderer, "DrawingGame\\clock.png"))
    {
        cout << " Failed to load clock texture" << endl;
        success = false;
    }

    if (!pauseTexture.loadFromFile(renderer, "DrawingGame\\pause.png"))
    {
        cout << " Failed to load pause texture " << endl;
        success = false;
    }

    for (int i = 0; i < 3; i++)
    {
        if (!timeLine[i].loadFromFile(renderer, timeLinePath[i]))
        {
            cout << " Failed to load time line " << i + 1 << endl;
            success = false;
        }
    }

    for (int i = 0; i < numberButton; i++)
    {
        if (!menuParts[i].loadFromFile(renderer, menuPaths[i]))
        {
            cout << "Failed to load menu parts " << endl;
            success = false;
        }
        else
        {
            menuRects[i].w = menuParts[i].getWidth();
            menuRects[i].h = menuParts[i].getHeight();
            menuRects[i].x = 1300;
            menuRects[i].y = menuRects[i].h * i + 275 + 50  * i;
        }
    }
    if (!menuTexture.loadFromFile(renderer, "DrawingGame\\menu.png"))
    {
        cout << " Failed to load menu texture " << endl;
        success = false;
    }

    if(!loadingTexture.loadFromFile(renderer, "DrawingGame\\loading.png") || !loadingFrame.loadFromFile(renderer, "DrawingGame\\loadingFrame.png"))
    {
        cout << "Failed to load loading texture " << endl;
        success = false;
    }
    else
    {
        loadingRect.x = 0;
        loadingRect.y = 0;
        loadingRect.w = 0;
        loadingRect.h = loadingTexture.getHeight();
    }

    for (int i = 0; i < 3; i++)
    {
        if(!mapTexture[i].loadFromFile(renderer, mapTexturePath[i]))
        {
            cout << " Failed to load map texture " << i + 1 << endl;
            success = false;
        }
        else
        {
            mapRect[i].w = mapTexture[i].getWidth();
            mapRect[i].h = mapTexture[i].getHeight();

            mapRect[i].x = (SCREEN_WIDTH - mapRect[i].w * 3) / 4 * (i + 1) + mapRect[i].w * i;
            mapRect[i].y = (SCREEN_HEIGHT - mapRect[i].h) / 2;
        }
    }

    if (!blackGround.loadFromFile(renderer, "DrawingGame\\blackGround.png"))
    {
        cout << " Failed to load black ground " << endl;
        success = false;
    }

    if (!guideTexture.loadFromFile(renderer, "DrawingGame\\guide.png") || !backToMenuTexture[0].loadFromFile(renderer, "DrawingGame\\menu_back to menu.png")||
        !backToMenuTexture[1].loadFromFile(renderer, "DrawingGame\\menu_mainMenu.png") ||
        !backToGameTexuture.loadFromFile(renderer, "DrawingGame\\menu_back to game.png"))
    {
        cout << " Failed to load guide or backtomenu textures " << endl;
        success = false;
    }
    else
    {
        guideRect.x = 0;
        guideRect.y = 0;
        guideRect.w = SCREEN_WIDTH;
        guideRect.h = SCREEN_HEIGHT;

        backToMenuRect[0] = {20, 20, backToMenuTexture->getWidth(), backToMenuTexture->getHeight()};

        backToMenuRect[1] = {(SCREEN_WIDTH - backToMenuTexture[1].getWidth()) / 2, 800, backToMenuTexture[1].getWidth(), backToMenuTexture[1].getHeight()};
        backToGameRect = {(SCREEN_WIDTH - backToGameTexuture.getWidth()) / 2, 650, backToGameTexuture.getWidth(), backToGameTexuture.getHeight() };
    }

    //load fonts
    gFont = TTF_OpenFont("Fonts\\Arialn.ttf", 28);
    tFont = TTF_OpenFont ("Fonts\\Friz Quadrata Bold BT.ttf", 30);
    eFont = TTF_OpenFont ("Fonts\\pricedow.ttf", 200);
    e2Font = TTF_OpenFont ("Fonts\\pricedow.ttf", 50);
    if (gFont == NULL || tFont == NULL || eFont == NULL)
    {
        cout << " Failed to open font " << TTF_GetError() << endl;
        success = false;
    }
    else
    {
        SDL_Color reloadColor = { 0, 0, 0 };
        SDL_Color failedColor = {255, 0, 0};
        SDL_Color passedColor = {213, 145, 8};
        reloadingTexture.loadFromRenderedText(renderer, gFont, "Reloading...", reloadColor);

        missionFailedTexture.loadFromRenderedText(renderer, eFont, "Mission Failed", failedColor);
        missionPassedTexture.loadFromRenderedText(renderer, eFont, "Mission Passed", passedColor);

        reasonFailedTexture[0].loadFromRenderedText(renderer, e2Font,"Time's up! " " You haven't finished mission on time" , failedColor);
        reasonFailedTexture[1].loadFromRenderedText(renderer, e2Font, "You died too many times! " " The base cannot repair your tank any more" , failedColor);
    }


    //load sounds
    ore_takeDameSound = Mix_LoadWAV("Sounds\\oreTakeDamage (mp3cut.net).wav" );
    ore_brokenSound = Mix_LoadWAV("Sounds\\oreBreak.wav" );
    takeOreSound = Mix_LoadWAV("Sounds\\takeOreSound.wav" );

    tank_shootSound = Mix_LoadWAV("Sounds\\gun-gunshot-02.wav" );
    tank_takeDameSound = Mix_LoadWAV("Sounds\\takeDamage.wav" );
    tank_armorSound = Mix_LoadWAV("Sounds\\metalSound4.wav");
    tank_reloadSound = Mix_LoadWAV("Sounds\\reloadingVoice.wav");
    tank_runOutOfBulletSound = Mix_LoadWAV("Sounds\\run out of bullet.wav");

    buttonSound = Mix_LoadWAV ("Sounds\\button.wav");
    upgradeSound = Mix_LoadWAV("Sounds\\upgradeSound1.wav");

    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);

    electricSound = Mix_LoadWAV("Sounds\\electric.wav");
    Mix_VolumeChunk (electricSound, MIX_MAX_VOLUME / 2);

    for (int i = 0; i < numberBotTank; i++)
    {
        bot_shootSound[i] = Mix_LoadWAV("Sounds\\gun-gunshot-02.wav" );
        bot_takeDameSound[i] =  Mix_LoadWAV("Sounds\\takeDamage.wav" );
        bot_armorSound[i] = Mix_LoadWAV("Sounds\\metalSound4.wav");
    }

    if (ore_takeDameSound == NULL || ore_brokenSound == NULL || takeOreSound == NULL)
    {
        cout << " Failed to load ore sounds " << Mix_GetError() << endl;
        success = false;
    }

    if (tank_shootSound == NULL || tank_takeDameSound == NULL)
    {
        cout << " Failed to load tank sounds " << endl;
        success = false;
    }

    return success;
}

int main(int argc, char* argv[])
{

    srand(time(NULL));
    if (!init())
    {
        cout << "Failed to init SDL " << endl;
    }
    else
    {
        if (!loadMediaTank())
        {
            cout << "Failed to load media " << endl;
        }
        else
        {
            setGameData();

            vector <SDL_Rect> tankRects;
            tankRects.push_back(tank.getRect());
            LTimer timer;

            bool quit = false;
            SDL_Event e;

            while (!quit)
            {
                while (SDL_PollEvent(&e) != 0)
                {
                    if (e.type == SDL_QUIT )
                    {
                        quit = true;
                    }

                    switch (GAME_STATUS)
                    {
                        case IN_MENU:
                            handleEventForMenu(e);
                            break;

                        case CHOOSE_MAP:
                            handleEventForChooseMap(e);
                            break;

                        case CHOOSE_SIDE:
                            handleEventForchooseSide(e);
                            break;

                        case STARTED:
                            if (!PAUSE)
                            {
                                tank.handleEvent(e);
                            }
                            else
                            {
                                handleEvenWhenPaused(e);
                            }

                            break;

                        case QUIT:
                            quit = true;
                            break;

                        case GUIDE:
                            handleEventInGuide(e);
                            break;

                        case LOADING:
                            break;

                        case END_GAME_FAILED:
                            if (!PAUSE)
                            {
                                tank.handleEvent(e);
                            }
                            else
                            {
                                handleEvenWhenPaused(e);
                            }
                            break;

                        case END_GAME_PASSED:
                            if (!PAUSE)
                            {
                                tank.handleEvent(e);
                            }
                            else
                            {
                                handleEvenWhenPaused(e);
                            }
                            break;

                    }



                    if (GAME_STATUS == STARTED && e.type == SDL_KEYDOWN)
                    {

                        if (e.key.keysym.sym == SDLK_f)
                        {
                            Mix_PlayChannel(-1, buttonSound, 0);
                            doRenderTab = !doRenderTab;
                        }

                        if (e.key.keysym.sym == SDLK_ESCAPE)
                        {
                            Mix_PlayChannel(-1, buttonSound, 0);
                            PAUSE = !PAUSE;
                        }

                        if (e.key.keysym.sym == SDLK_r)
                        {
                            Mix_PlayChannel(-1, buttonSound, 0);
                        }

                        if (tank.upgradeTableOpened())
                        {
                            switch (e.key.keysym.sym)
                            {
                                case SDLK_1:
                                boarderIndex = 1;
                                break;

                                case SDLK_2:
                                boarderIndex = 2;
                                break;

                                case SDLK_3:
                                boarderIndex = 3;
                                break;

                                case SDLK_4:
                                boarderIndex = 4;
                                break;

                                case SDLK_5:
                                boarderIndex = 5;
                                break;

                                case SDLK_6:
                                boarderIndex = 6;
                                break;

                                case SDLK_7:
                                boarderIndex = 7;
                                break;
                            }
                        }

                    }
                }

                float time = timer.getTicks() / 1000.f;
                timer.start();


                    if (GAME_STATUS == IN_MENU)
                    {
                        renderMenu();
                    }
                    else if (GAME_STATUS == CHOOSE_MAP)
                    {
                        chooseMap();
                    }
                    else if (GAME_STATUS == GUIDE)
                    {
                        renderGuide();
                    }
                    else if (GAME_STATUS == LOADING)
                    {
                        renderLoading(time);
                    }

                    else if (GAME_STATUS == QUIT)
                    {
                        quit = true;
                    }

                    else
                    {
                        SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
                        SDL_RenderClear(renderer);

                        for (int i = 0; i < NUMBER_BLOCK_HEIGHT; i++)
                        {
                            for (int j = 0; j < NUMBER_BLOCK_WIDTH; j++)
                            {

                                switch (GAME_BLOCK[i][j].index)
                                {
                                    case 0:
                                        block[GAME_MAP][0].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                    case 1:
                                        block[GAME_MAP][1].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                    case 4:
                                        block[GAME_MAP][0].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                    case 5:
                                        block[GAME_MAP][2].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                    case 6:
                                        block[GAME_MAP][0].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;
                                    case 7:
                                        block[GAME_MAP][0].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;
                                    case 8:
                                        block[GAME_MAP][0].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                    case 9:
                                        block[GAME_MAP][3].render(renderer, GAME_BLOCK[i][j].block.x, GAME_BLOCK[i][j].block.y);
                                        break;

                                }
                            }

                        }
                        iron.render(renderer);
                        titan.render(renderer);
                        sulfur.render(renderer);

                        AllyFlag.render(renderer, FlagAllyX, FlagAllyY);
                        TreatyFlag.render(renderer, FlagTreatyX, FlagTreatyY);

                        if (GAME_STATUS == CHOOSE_SIDE)
                        {
                            chooseSide();
                        }

                        else
                        {
                            renderGameTime();
                            renderNumberBullet(tank.getNumberAvailableBullet(), tank.getNumberBulletInStorage());
                            renderNumberOreTexture( tank.getNumberIron(), tank.getNumberTitan(), tank.getNumberSulfur());
                            renderKillsAndDeaths();

                            if (!PAUSE)
                            {
                                tank.move(GAME_BLOCK, GAME_walls, GAME_river, botTank, time, iron, titan, sulfur);
                                tank.doShoot(GAME_BLOCK, GAME_walls, botTank, time, iron, titan, sulfur);
                                tank.receiveUpgrades(botTank);
                            }


                            for (Uint8 i = 0; i < numberBotTank; i++)
                            {
                                if (!PAUSE)
                                {
                                    botTank[i].AI_move(time, tank);
                                    botTank[i].AI_checkEnemy(tank);
                                    botTank[i].AI_shoot(GAME_BLOCK, GAME_walls, tank, time, iron, titan, sulfur);
                                }
                                botTank[i].render();
                                botTank[i].checkStatus(&tank);
                                botTank[i].AI_increasePower(GAME_TIMER.getTicks());
                            }

                            tank.render();
                            botTank[0].turretAttack(tank, time);

                            tankRects[0] = tank.getRect();

                            iron.checkStatus(tankRects);
                            titan.checkStatus(tankRects);
                            sulfur.checkStatus(tankRects);

                            tank.checkStatus();

                            if(tank.ifIsReloading())
                            {
                                renderReloading();
                            }

                            if (doRenderTab)
                            {
                                tabTexture.render(renderer, tabPosX, tabPosY);

                                renderNumberStoredOres(tank.getNumberStoredIron(), tank.getNumberStoredTitan(), tank.getNumberStoredSulfur());

                                renderLevels(tank);
                            }

                            if (tank.upgradeTableOpened())
                            {
                                renderUpgradeTable(tank);

                            }
                            else
                            {
                                boarderIndex = 0;
                            }


                            if (PAUSE)
                            {
                                renderPause();

                                GAME_TIMER.pause();

                                tank.pauseAllTimer();

                                for (int i = 0; i < numberBotTank; i++)
                                {
                                    botTank[i].pauseAllTimer();
                                }
                            }
                            else
                            {
                                GAME_TIMER.unpause();

                                tank.unPauseAllTimer();

                                for (int i = 0; i < numberBotTank; i++)
                                {
                                    botTank[i].unPauseAllTimer();
                                }
                            }

                            //check win or lose
                            if (botTank[0].getTurretHP(0) == 0 && GAME_STATUS != END_GAME_PASSED)
                            {
                                GAME_STATUS = END_GAME_PASSED;

                                Uint32 seconds =  GAME_TIMER.getTicks() / 1000;
                                Uint32 minutes =  seconds / 60;
                                seconds = seconds - minutes * 60;
                                string timeString = (minutes >= 10 ? "" : "0") + to_string (minutes) + ':' + (seconds >= 10 ? "" : "0") + to_string(seconds);
                                string passedString = "Time passed  " + timeString;
                                SDL_Color passedColor = {213, 145, 8};
                                timePassedTexture.loadFromRenderedText(renderer, e2Font, passedString.c_str(), passedColor);
                            }

                            if (GAME_TIMER.getTicks() >= TIME_FOR_MISSION && GAME_STATUS != END_GAME_PASSED)
                            {
                                GAME_STATUS = END_GAME_FAILED;
                                reasonFailed[0] = true;
                                reasonFailed[1] = false;
                            }
                            else if (tank.getDeaths() > NUMBER_LIFE && GAME_STATUS != END_GAME_PASSED)
                            {
                                GAME_STATUS = END_GAME_FAILED;
                                reasonFailed[0] = false;
                                reasonFailed[1] = true;
                            }

                            if (GAME_STATUS == END_GAME_FAILED)
                            {
                                renderMissionFailed();
                            }
                            else if (GAME_STATUS == END_GAME_PASSED)
                            {
                                renderMissionPassed();
                            }
                        }
                    }

                    SDL_RenderPresent(renderer);

            }

            iron.clear();
            titan.clear();
            sulfur.clear();
        }


    }

    close();

    return 0;
}
