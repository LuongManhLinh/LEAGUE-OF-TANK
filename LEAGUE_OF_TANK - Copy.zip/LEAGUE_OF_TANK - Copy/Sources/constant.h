#pragma once



const int SCREEN_WIDTH =1920;
const int SCREEN_HEIGHT = 1080;
const std::string WINDOW_TITLE = "LEAGUE OF TANK";

const double pi = 3.14159;

const int BLOCK_SIDE = 36;
const int NUMBER_BLOCK_WIDTH = 54;
const int NUMBER_BLOCK_HEIGHT = 30;

const static int NUMBER_IRON = 20;
const static int NUMBER_TITAN = 16;
const static int NUMBER_SULFUR = 10;

const Uint32 TIME_FOR_MISSION = 720000;
const Uint8 NUMBER_LIFE = 5;

