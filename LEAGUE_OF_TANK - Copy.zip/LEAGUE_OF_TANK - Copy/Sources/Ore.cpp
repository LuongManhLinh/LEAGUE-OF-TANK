#include "Ore.h"

Ore::Ore(int n)
{
    number = n;
    rect = new SDL_Rect [number];
    rawTexture = new LTexture [number];
    lootTexture = new LTexture [number];

    HP = new float [number];

    isTaken = new bool [number];

    respawnTimer = new LTimer [number];
    waitForTakingTimer = new LTimer [number];

    for (int i = 0; i < number; i++)
    {
        rect[i].w = BLOCK_SIDE;
        rect[i].h = BLOCK_SIDE;

        isTaken[i] =false;
    }

    playTakeDameSound = false;
    playBrokenSound = false;
}

void Ore::setHP (float _HP)
{
    MAX_HP = _HP;
    for (int i = 0 ; i < number; i++)
    {
        HP[i] = MAX_HP;
    }
}

void Ore::setRandomPos(vector<ArrayIndex> _randomPos)
{
    allPos = _randomPos;

    //khởi tạo vector lưu trữ các số từ 0 đến số phần tử của randomPos

    for (int i = 0; i < number * 2; i++)
    {
        notContainOre.push_back(i);
    }

    for (int i = 0; i < number; i++)
    {
        //lấy ngẫu nhiên 1 số trong số các số từ 0 đến số phần từ của nums
        int index = rand() % (number * 2 - i);
        //lưu giá trị của randomPos ở vị trí của nums ngẫu nhiên
        pos.push_back(allPos[notContainOre[index]]);
        containOre.push_back(notContainOre[index]);
        //xóa phần tử ở vị trí index của nums
        notContainOre.erase(notContainOre.begin() + index);

        rect[i].x = pos[i].x * BLOCK_SIDE;
        rect[i].y = pos[i].y * BLOCK_SIDE;
    }
}
void Ore::setTexture(LTexture &_rawTexture, LTexture &_lootTexture)
{
    for (int i = 0; i < number; i++)
    {
        rawTexture[i] = _rawTexture;
        lootTexture[i] = _lootTexture;
    }
}

void Ore::decreaseHP(int index, float amount)
{
    float preHP = HP[index];
    HP[index] -= amount;
    float afterHP = HP[index];

    if (preHP > 0 && afterHP <= 0)
    {
        playBrokenSound = true;
    }
    else if (preHP > 0 && afterHP > 0)
    {
        playTakeDameSound = true;
    }

    if (HP[index] <= 0)
    {
        HP[index] = 0;
    }

}

void Ore::checkStatus(vector<SDL_Rect>& tankRects)
{
    for (int index = 0; index < number; index++)
    {
        if (isTaken[index])
        {
            if (respawnTimer[index].getTicks() >= RESPAWN_TIME)
            {
                isTaken[index] = false;
                respawnTimer[index].stop();

                HP[index] = MAX_HP;

                Uint8 newIndex = rand() % notContainOre.size();
                //kiem tra xem vi tri co bi trung voi vi tri xe tang k
                while (true)
                {
                    SDL_Rect intendRect = {allPos[notContainOre[newIndex]].x * BLOCK_SIDE, allPos[notContainOre[newIndex]]. y * BLOCK_SIDE, BLOCK_SIDE, BLOCK_SIDE};
                    int countCoincidence = 0;
                    for (SDL_Rect eachTankRect : tankRects)
                    {
                        if (checkCollision(eachTankRect, intendRect))
                        {
                            countCoincidence++;
                            newIndex++;
                            if (newIndex == notContainOre.size())
                            {
                                newIndex = 0;
                            }
                            break;
                        }
                    }
                    if (countCoincidence == 0)
                    {
                        break;
                    }
                }
                //
                pos[index] = allPos[notContainOre[newIndex]];

                containOre[index] = notContainOre[newIndex];
                notContainOre.erase(notContainOre.begin() + newIndex);

                rect[index].x = pos[index].x * BLOCK_SIDE;
                rect[index].y = pos[index].y * BLOCK_SIDE;
                rect[index].h = BLOCK_SIDE;
                rect[index].w = BLOCK_SIDE;

            }
            waitForTakingTimer[index].stop();

        }

        if (!isTaken[index] && HP[index] == 0 && waitForTakingTimer[index].getTicks() == 0)
        {
            waitForTakingTimer[index].start();
            rect[index].x -= 1;
            rect[index].y -= 1;
            rect[index].h += 2;
            rect[index].w += 2;
        }
        if (waitForTakingTimer[index].getTicks() >= WAIT_FOR_TAKING_TIME)
        {
            waitForTakingTimer[index].stop();
            beTaken(index);
        }

    }

    if (playTakeDameSound)
    {
        Mix_PlayChannel (-1, takeDameSound, 0);
        playTakeDameSound = false;
    }
    if (playBrokenSound)
    {
        Mix_PlayChannel (-1, brokenSound, 0);
        playBrokenSound = false;
    }

}

void Ore::beTaken(int index)
{
    isTaken[index] = true;

    rect[index].x = -100;
    rect[index].y = -100;

    respawnTimer[index].start();

    notContainOre.push_back(containOre[index]);
}


void Ore::render(SDL_Renderer *renderer)
{
    for (int i = 0; i < number; i++)
    {

        if (HP[i] > 0)
        {
            rawTexture[i].render(renderer, pos[i].x * BLOCK_SIDE, pos[i].y * BLOCK_SIDE);
        }
        else if (!isTaken[i])
        {
            lootTexture[i].render(renderer, pos[i].x * BLOCK_SIDE, pos[i].y * BLOCK_SIDE) ;
        }

    }
}

SDL_Rect Ore::getRect(int index)
{
    return rect[index];
}


float Ore::getHP(int index)
{
    return HP[index];
}

void Ore::clear()
{
    number = 0;
    delete[] rect;
    delete[] rawTexture;
    delete[] lootTexture;
    delete[] HP;
    delete[] isTaken;
    delete[] respawnTimer;
    delete[] waitForTakingTimer;

    allPos.clear();
    pos.clear();
}

void Ore::reset()
{
    for (int i = 0; i < number; i++)
    {
        HP[i] = MAX_HP;
        isTaken[i] = false;
        respawnTimer[i].stop();
        waitForTakingTimer[i].stop();
    }
    allPos.clear();
    pos.clear();
    notContainOre.clear();
    containOre.clear();
}

void Ore::setSound(Mix_Chunk *takeDameSound, Mix_Chunk *brokenSound)
{
    this->takeDameSound = takeDameSound;
    this->brokenSound = brokenSound;

    //Mix_VolumeChunk (this->takeDameSound, MIX_MAX_VOLUME * 10);
    Mix_VolumeChunk (this->brokenSound, MIX_MAX_VOLUME * 2);
}
